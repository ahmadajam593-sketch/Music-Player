package com.nazier.cinema
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.*

sealed class Scr {
    object Home : Scr(); object Search : Scr(); object Saved : Scr(); object Cats : Scr(); object Live : Scr()
    data class Play(val name: String, val url: String) : Scr()
    data class Grid(val title: String, val path: String, val q: String, val tv: Boolean?) : Scr()
    data class Det(val i: Item) : Scr()
}
val Navy = Color(0xFF0B1030); val Teal = Color(0xFF2EC4A6)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); val st = Store(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App(st) } } } }
}

@Composable fun App(st: Store) {
    val stack = remember { mutableStateListOf<Scr>(Scr.Home) }
    val back = { if (stack.size > 1) stack.removeAt(stack.lastIndex); Unit }
    val go = { s: Scr -> stack.add(s); Unit }
    BackHandler(stack.size > 1) { back() }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, Color(0xFF05060F)))).statusBarsPadding()) {
        when (val s = stack.last()) {
            Scr.Home -> Home(st, go)
            is Scr.Grid -> GridScr(s, go, back)
            is Scr.Det -> Detail(s.i, st, back)
            Scr.Search -> SearchScr(go, back)
            Scr.Saved -> SavedScr(st, go, back)
            Scr.Cats -> CatsScr(go, back)
            Scr.Live -> LiveScr(st, go, back)
            is Scr.Play -> PlayScr(s.name, s.url, back)
        }
    }
}

fun ago(t: Long): String { val h = (System.currentTimeMillis() - t) / 3600000; return if (h < 1) "الآن" else "منذ $h ساعة" }

@Composable fun Tile(m: Modifier, title: String, icon: ImageVector, brush: Brush, bar: Color?, key: String, st: Store, size: Int = 56, onClick: () -> Unit) {
    Box(m.padding(6.dp).clip(RoundedCornerShape(14.dp)).background(brush).clickable(onClick = onClick)) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, Modifier.size(size.dp), tint = Color(0xFFCFEFF5))
            Text(title, fontSize = if (size > 40) 20.sp else 15.sp, color = Color(0xFFE6F6FA), fontWeight = FontWeight.Medium)
        }
        if (bar != null) {
            var stamp by remember { if (st.stamp(key) == 0L) st.touch(key); mutableLongStateOf(st.stamp(key)) }
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(bar).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFFE6F6FA)).clickable { Api.clear(); st.touch(key); stamp = st.stamp(key) }.padding(6.dp)) {
                    Icon(Icons.Filled.Refresh, "تحديث", tint = Navy) }
                Spacer(Modifier.width(10.dp)); Text("آخر تحديث: ${ago(stamp)}", fontSize = 12.sp, color = Color.White)
            }
        }
    }
}

@Composable fun Home(st: Store, go: (Scr) -> Unit) {
    val live = Brush.verticalGradient(listOf(Color(0xFF00D4B0), Color(0xFF00B8E6), Color(0xFF1E5BFF)))
    val red = Brush.horizontalGradient(listOf(Color(0xFFD6336C), Color(0xFFE8C4B0)))
    val pur = Brush.horizontalGradient(listOf(Color(0xFF7B5CF0), Color(0xFF00D0F0)))
    val tl = SolidColor(Teal)
    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Row(Modifier.weight(1f)) {
            Column(Modifier.weight(2f)) {
                Row(Modifier.weight(1.6f)) {
                    Tile(Modifier.weight(1f).fillMaxHeight(), "مسلسلات", Icons.Filled.Theaters, pur, Color(0x55003A66), "tv", st) { go(Scr.Grid("مسلسلات", "tv/popular", "", true)) }
                    Tile(Modifier.weight(1f).fillMaxHeight(), "أفلام", Icons.Filled.PlayCircleOutline, red, Color(0x66701A3A), "mv", st) { go(Scr.Grid("أفلام", "movie/popular", "", false)) }
                }
                Row(Modifier.weight(1f)) {
                    Tile(Modifier.weight(1f).fillMaxHeight(), "المفضلة وقائمة المشاهدة", Icons.Filled.Bookmark, tl, null, "", st, 28) { go(Scr.Saved) }
                    Tile(Modifier.weight(1f).fillMaxHeight(), "بحث", Icons.Filled.Search, tl, null, "", st, 28) { go(Scr.Search) }
                    Tile(Modifier.weight(1f).fillMaxHeight(), "الأقسام", Icons.Filled.GridView, tl, null, "", st, 28) { go(Scr.Cats) }
                }
            }
            Tile(Modifier.weight(1f).fillMaxHeight(), "تلفزيون مباشر", Icons.Filled.LiveTv, live, Color(0x66002F99), "tr", st) { go(Scr.Live) }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("المصادر: TMDB · TVmaze · Jikan", fontSize = 12.sp, color = Color.White)
            Text(if (BuildConfig.TMDB_KEY.isEmpty()) "مفتاح TMDB غير مضبوط" else "مفتاح TMDB مضبوط", fontSize = 12.sp, color = Color.White)
        }
    }
}

@Composable fun Bar(title: String, back: () -> Unit) = Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
    IconButton(back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") }; Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold) }

@Composable fun Posters(l: List<Item>, go: (Scr) -> Unit, more: (() -> Unit)? = null) {
    val gs = rememberLazyGridState()
    LaunchedEffect(gs, l.size) { snapshotFlow { gs.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }.collect { if (it >= l.size - 8) more?.invoke() } }
    LazyVerticalGrid(GridCells.Adaptive(115.dp), state = gs, contentPadding = PaddingValues(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(l, key = { it.id }) { i ->
            Column(Modifier.clickable { go(Scr.Det(i)) }) {
                AsyncImage(i.poster, null, Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(10.dp)).background(Color(0xFF1B1F3B)), contentScale = ContentScale.Crop)
                Text(i.title, maxLines = 1, fontSize = 12.sp); Text("★ ${"%.1f".format(i.rating)} · ${i.date.take(4)}", fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
}

@Composable fun Body(r: Result<List<Item>>?, go: (Scr) -> Unit) = when {
    r == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
    r.isFailure -> Box(Modifier.fillMaxSize().padding(24.dp), Alignment.Center) { Text("تعذر التحميل. تأكد من الإنترنت ومن ضبط TMDB_KEY.\n${r.exceptionOrNull()?.message}") }
    r.getOrThrow().isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("لا نتائج") }
    else -> Posters(r.getOrThrow(), go)
}

@Composable fun GridScr(s: Scr.Grid, go: (Scr) -> Unit, back: () -> Unit) {
    var genre by remember { mutableStateOf<Int?>(null) }
    var list by remember { mutableStateOf<List<Item>>(emptyList()) }
    var page by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var end by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    fun more() {
        if (busy || end) return
        busy = true; val p = page + 1; val g = genre
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { Api.page(s.path, s.q, s.tv, p, g) } }
            if (g == genre) {
                busy = false
                r.onSuccess { pg ->
                    if (pg.raw == 0) end = true else { list = (list + pg.items).distinctBy { it.id }; page = p; if (pg.items.isEmpty()) more() }
                }.onFailure { err = it.message; end = true }
            }
        }
    }
    LaunchedEffect(genre) { list = emptyList(); page = 0; end = false; err = null; busy = false; more() }
    val tv = s.tv == true
    val g = listOf("الكل" to null, "أكشن" to if (tv) 10759 else 28, "كوميدي" to 35, "دراما" to 18, "خيال علمي" to if (tv) 10765 else 878, "أنمي" to -1) +
        (if (tv) emptyList() else listOf("رعب" to 27, "رومانسي" to 10749))
    Column { Bar(s.title, back)
        LazyRow(contentPadding = PaddingValues(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(g) { (n, id) -> FilterChip(genre == id, { genre = id }, { Text(n) }) } }
        when {
            list.isEmpty() && err != null -> Box(Modifier.fillMaxSize().padding(24.dp), Alignment.Center) { Text("تعذر التحميل. تأكد من الإنترنت ومن ضبط TMDB_KEY. $err") }
            list.isEmpty() && !end -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("لا نتائج") }
            else -> Posters(list, go) { more() }
        } }
}

@Composable fun SearchScr(go: (Scr) -> Unit, back: () -> Unit) {
    var q by remember { mutableStateOf("") }; var st by remember { mutableStateOf<Result<List<Item>>?>(Result.success(emptyList())) }
    LaunchedEffect(q) { if (q.trim().length > 1) { delay(400); st = null; st = withContext(Dispatchers.IO) { runCatching { Api.search(q.trim()) } } } }
    Column { Bar("بحث", back)
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp), singleLine = true, placeholder = { Text("فيلم، مسلسل، أنمي…") })
        Body(st, go) }
}

@Composable fun SavedScr(st: Store, go: (Scr) -> Unit, back: () -> Unit) {
    var k by remember { mutableStateOf("fav") }
    Column { Bar("المفضلة وقائمة المشاهدة", back)
        Row(Modifier.padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(k == "fav", { k = "fav" }, { Text("المفضلة") }); FilterChip(k == "watch", { k = "watch" }, { Text("قائمة المشاهدة") }) }
        Body(Result.success(st.load(k)), go) }
}

@Composable fun Detail(i: Item, st: Store, back: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    var sea by remember { mutableStateOf<List<Pair<String, List<String>>>>(emptyList()) }
    var wh by remember { mutableStateOf<Api.Where?>(null) }
    val uri = LocalUriHandler.current
    LaunchedEffect(i.id) { wh = withContext(Dispatchers.IO) { runCatching { Api.where(i) }.getOrNull() } }
    LaunchedEffect(i.id) { if (i.tv) sea = withContext(Dispatchers.IO) { runCatching { Api.seasons(i) }.getOrDefault(emptyList()) } }
    LazyColumn {
        item { Box { AsyncImage(i.back ?: i.poster, null, Modifier.fillMaxWidth().height(220.dp), contentScale = ContentScale.Crop)
            IconButton(back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") } } }
        item { Column(Modifier.padding(14.dp)) {
            Text(i.title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("★ ${"%.1f".format(i.rating)} · ${i.date} · ${i.src}", color = Color.Gray)
            Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val f = tick.let { st.has("fav", i) }; val w = tick.let { st.has("watch", i) }
                Button({ st.toggle("fav", i); tick++ }) { Icon(if (f) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null); Text(" مفضلة") }
                OutlinedButton({ st.toggle("watch", i); tick++ }) { Icon(if (w) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder, null); Text(" للمشاهدة") }
            }
            wh?.let { w ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    w.trailer?.let { u -> OutlinedButton({ uri.openUri(u) }) { Icon(Icons.Filled.PlayArrow, null); Text(" الإعلان") } }
                    w.link?.let { u -> OutlinedButton({ uri.openUri(u) }) { Text("أين أشاهده؟") } }
                }
                Text(if (w.names.isEmpty()) "غير متوفر على منصات في منطقتك" else "متوفر على: " + w.names.joinToString("، "), color = Teal, modifier = Modifier.padding(top = 6.dp))
                Text("بيانات المشاهدة: JustWatch عبر TMDB", fontSize = 10.sp, color = Color.Gray)
            }
            Text(i.about.ifEmpty { "لا يوجد وصف." }, modifier = Modifier.padding(top = 8.dp)) } }
        sea.forEach { (n, eps) -> item { Column(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            Text(n, fontWeight = FontWeight.Bold, color = Teal); eps.forEach { Text(it, fontSize = 13.sp) } } } }
    }
}

@Composable fun CatsScr(go: (Scr) -> Unit, back: () -> Unit) {
    val s = "sort_by=popularity.desc"
    val l = listOf(
        Scr.Grid("أفلام عربية", "discover/movie", "with_original_language=ar&$s", false),
        Scr.Grid("أفلام أجنبية", "discover/movie", "with_original_language=en&$s", false),
        Scr.Grid("مسلسلات تركية", "discover/tv", "with_original_language=tr&$s", true),
        Scr.Grid("مسلسلات عربية", "discover/tv", "with_original_language=ar&$s", true),
        Scr.Grid("مسلسلات رمضان 2026", "discover/tv", "with_original_language=ar&first_air_date.gte=2026-02-10&first_air_date.lte=2026-03-25&$s", true),
        Scr.Grid("مسلسلات أجنبية", "discover/tv", "with_original_language=en&$s", true),
        Scr.Grid("أحدث الأفلام", "movie/now_playing", "", false),
        Scr.Grid("أحدث المسلسلات", "tv/on_the_air", "", true),
        Scr.Grid("الأكثر رواجاً", "trending/all/week", "", null))
    Column { Bar("الأقسام", back)
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(l) { g -> Box(Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(14.dp)).background(Teal).clickable { go(g) }.padding(16.dp), Alignment.CenterStart) {
                Text(g.title, fontSize = 18.sp, color = Navy, fontWeight = FontWeight.Bold) } } } }
}

@Composable fun LiveScr(st: Store, go: (Scr) -> Unit, back: () -> Unit) {
    var url by remember { mutableStateOf(st.url()) }; var q by remember { mutableStateOf("") }
    var r by remember { mutableStateOf<Result<List<Ch>>?>(null) }; var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    fun load() { if (url.isBlank()) return; st.setUrl(url.trim()); busy = true
        scope.launch { r = withContext(Dispatchers.IO) { runCatching { Api.channels(url.trim()) } }; busy = false } }
    LaunchedEffect(Unit) { load() }
    Column { Bar("تلفزيون مباشر", back)
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp), singleLine = true, placeholder = { Text("رابط قائمة M3U الخاصة بك") })
        Text("أضف رابط قائمة قنوات لديك حق مشاهدتها. التطبيق لا يوفر قنوات ولا روابط بث.", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(12.dp, 4.dp))
        Button({ load() }, Modifier.padding(horizontal = 12.dp)) { Text("تحميل القنوات") }
        when {
            busy -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            r?.isFailure == true -> Text("تعذر تحميل القائمة: ${r?.exceptionOrNull()?.message}", Modifier.padding(16.dp))
            r != null -> {
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(12.dp), singleLine = true, placeholder = { Text("ابحث عن قناة") })
                val l = r!!.getOrThrow().filter { it.name.contains(q, true) }
                LazyColumn { items(l) { c -> Column(Modifier.fillMaxWidth().clickable { go(Scr.Play(c.name, c.url)) }.padding(14.dp)) {
                    Text(c.name, fontSize = 15.sp); if (c.group.isNotEmpty()) Text(c.group, fontSize = 11.sp, color = Color.Gray) } } }
            }
        } }
}

@Composable fun PlayScr(title: String, url: String, back: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true } }
    DisposableEffect(Unit) { onDispose { player.release() } }
    Column { Bar(title, back)
        AndroidView({ PlayerView(it).apply { this.player = player } }, Modifier.fillMaxWidth().weight(1f)) }
}
