package com.nazier.cinema
import android.content.Context
import org.json.*
import java.net.URL

data class Item(val id: String, val title: String, val poster: String?, val back: String?, val rating: Double, val date: String, val about: String, val tv: Boolean, val src: String, val sid: Int)
fun Item.toJson() = JSONObject().put("id", id).put("t", title).put("p", poster).put("b", back).put("r", rating).put("d", date).put("a", about).put("tv", tv).put("s", src).put("i", sid)
fun JSONObject.toItem() = Item(getString("id"), getString("t"), s("p"), s("b"), getDouble("r"), getString("d"), getString("a"), getBoolean("tv"), getString("s"), getInt("i"))
fun JSONObject.s(k: String): String? = if (isNull(k)) null else optString(k).ifEmpty { null }
fun <T> JSONArray.objs(f: (JSONObject) -> T) = (0 until length()).map { f(getJSONObject(it)) }

object Api {
    private val cache = HashMap<String, List<Item>>()
    fun clear() = cache.clear()
    private fun get(u: String) = URL(u).openConnection().apply { connectTimeout = 8000; readTimeout = 8000 }.getInputStream().bufferedReader().use { it.readText() }
    private fun tmdb(path: String, q: String = "", lang: String = "ar") = JSONObject(get("https://api.themoviedb.org/3/$path?api_key=${BuildConfig.TMDB_KEY}&language=$lang&$q"))
    private fun tm(o: JSONObject, tv0: Boolean?): Item {
        val tv = o.s("media_type")?.let { it == "tv" } ?: (tv0 == true)
        val id = o.getInt("id")
        return Item("t$id", o.s("title") ?: o.s("name") ?: "", o.s("poster_path")?.let { "https://image.tmdb.org/t/p/w342$it" },
            o.s("backdrop_path")?.let { "https://image.tmdb.org/t/p/w780$it" }, o.optDouble("vote_average", 0.0),
            o.s("release_date") ?: o.s("first_air_date") ?: "", o.s("overview") ?: "", tv, "TMDB", id)
    }
    private fun vz(o: JSONObject): Item {
        val img = o.optJSONObject("image")?.s("medium"); val id = o.getInt("id")
        return Item("v$id", o.optString("name"), img, img, o.optJSONObject("rating")?.optDouble("average", 0.0) ?: 0.0,
            o.s("premiered") ?: "", (o.s("summary") ?: "").replace(Regex("<[^>]*>"), ""), true, "TVmaze", id)
    }
    private fun jk(o: JSONObject): Item {
        val img = o.optJSONObject("images")?.optJSONObject("jpg")?.s("image_url"); val id = o.getInt("mal_id")
        return Item("j$id", o.s("title") ?: "", img, img, o.optDouble("score", 0.0), o.optInt("year", 0).let { if (it > 0) "$it" else "" },
            o.s("synopsis") ?: "", o.s("type") != "Movie", "Jikan", id)
    }
    private fun dedupe(l: List<Item>) = l.distinctBy { it.title.lowercase() + it.date.take(4) }
    private fun jikan(path: String) = JSONObject(get("https://api.jikan.moe/v4/$path")).getJSONArray("data").objs { jk(it) }

    class Pg(val items: List<Item>, val raw: Int)
    class Where(val link: String?, val names: List<String>, val trailer: String?)
    fun page(path: String, q: String, tv: Boolean?, page: Int, genre: Int?): Pg {
        val t = if (tv == true) "tv" else "movie"
        val r = if (genre == -1) jikan("top/anime?page=$page") else try {
            val p = if (genre != null && !path.startsWith("discover")) "discover/$t" else path
            tmdb(p, q + (if (genre != null) "&with_genres=$genre" else "") + "&page=$page").getJSONArray("results").objs { tm(it, tv) }
        } catch (e: Exception) {
            if (tv == true && genre == null && page == 1) JSONArray(get("https://api.tvmaze.com/shows?page=0")).objs { vz(it) }.sortedByDescending { it.rating }.take(40) else throw e
        }
        return Pg(dedupe(r.filter { it.poster != null }), r.size)
    }
    fun where(i: Item): Where {
        if (i.src != "TMDB") return Where(null, emptyList(), null)
        val t = if (i.tv) "tv" else "movie"
        val tr = runCatching { tmdb("$t/${i.sid}/videos", "", "en-US").getJSONArray("results").objs { it }
            .firstOrNull { it.optString("site") == "YouTube" && it.optString("type") == "Trailer" }?.s("key") }.getOrNull()?.let { "https://www.youtube.com/watch?v=$it" }
        val cc = java.util.Locale.getDefault().country.ifEmpty { "SA" }
        val pr = runCatching { tmdb("$t/${i.sid}/watch/providers").getJSONObject("results").optJSONObject(cc) }.getOrNull()
        return Where(pr?.s("link"), pr?.optJSONArray("flatrate")?.objs { it.optString("provider_name") } ?: emptyList(), tr)
    }
    fun channels(u: String) = parseM3u(get(u))
    fun search(q: String): List<Item> {
        val e = java.net.URLEncoder.encode(q, "UTF-8")
        val r = listOf(
            runCatching { tmdb("search/multi", "query=$e").getJSONArray("results").objs { it }.filter { it.optString("media_type") != "person" }.map { tm(it, null) } },
            runCatching { JSONArray(get("https://api.tvmaze.com/search/shows?q=$e")).objs { vz(it.getJSONObject("show")) } },
            runCatching { jikan("anime?q=$e&limit=8") })
        if (r.all { it.isFailure }) throw r[0].exceptionOrNull()!!
        return dedupe(r.flatMap { it.getOrDefault(emptyList()) })
    }
    fun seasons(i: Item): List<Pair<String, List<String>>> = when (i.src) {
        "TMDB" -> tmdb("tv/${i.sid}").getJSONArray("seasons").objs { it }.filter { it.getInt("season_number") > 0 }.take(8).map { s ->
            val n = s.getInt("season_number")
            "الموسم $n" to tmdb("tv/${i.sid}/season/$n").getJSONArray("episodes").objs { "${it.getInt("episode_number")}. ${it.s("name") ?: ""}" } }
        "TVmaze" -> JSONArray(get("https://api.tvmaze.com/shows/${i.sid}/episodes")).objs { it }.groupBy { it.getInt("season") }
            .map { (n, e) -> "الموسم $n" to e.map { "${it.optInt("number")}. ${it.optString("name")}" } }
        else -> emptyList()
    }
}

data class Ch(val name: String, val url: String, val group: String)
fun parseM3u(text: String): List<Ch> {
    val out = mutableListOf<Ch>(); var name = ""; var grp = ""
    text.lineSequence().map { it.trim() }.forEach { l ->
        if (l.startsWith("#EXTINF")) { name = l.substringAfterLast(",").trim(); grp = Regex("group-title=\"([^\"]*)\"").find(l)?.groupValues?.get(1) ?: "" }
        else if (l.isNotEmpty() && !l.startsWith("#")) { out.add(Ch(name.ifEmpty { l }, l, grp)); name = ""; grp = "" }
    }
    return out
}

class Store(c: Context) {
    fun url() = p.getString("m3u", "") ?: ""
    fun setUrl(u: String) = p.edit().putString("m3u", u).apply()
    private val p = c.getSharedPreferences("s", 0)
    fun load(k: String) = runCatching { JSONArray(p.getString(k, "[]")).objs { it.toItem() } }.getOrDefault(emptyList())
    fun has(k: String, i: Item) = load(k).any { it.id == i.id }
    fun toggle(k: String, i: Item) { val l = load(k).toMutableList(); if (!l.removeAll { it.id == i.id }) l.add(i)
        p.edit().putString(k, JSONArray(l.map { it.toJson() }).toString()).apply() }
    fun stamp(k: String) = p.getLong("u$k", 0)
    fun touch(k: String) = p.edit().putLong("u$k", System.currentTimeMillis()).apply()
}
