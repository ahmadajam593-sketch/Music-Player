package com.musicplayer.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BrandViolet = Color(0xFF5B3DF5)
val BrandTeal = Color(0xFF12C2B0)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB7A6FF),
    onPrimary = Color(0xFF1B0F5C),
    secondary = Color(0xFF4FE0C8),
    background = Color(0xFF0B0B12),
    onBackground = Color(0xFFECEBF5),
    surface = Color(0xFF14141F),
    onSurface = Color(0xFFECEBF5),
    surfaceVariant = Color(0xFF1F1F2E),
    onSurfaceVariant = Color(0xFFA9A7BC),
    outline = Color(0xFF3A3950),
)

private val LightColors = lightColorScheme(
    primary = BrandViolet,
    onPrimary = Color.White,
    secondary = Color(0xFF0E9E8F),
    background = Color(0xFFF7F6FC),
    onBackground = Color(0xFF14141F),
    surface = Color.White,
    onSurface = Color(0xFF14141F),
    surfaceVariant = Color(0xFFECEAF7),
    onSurfaceVariant = Color(0xFF5E5C73),
    outline = Color(0xFFC9C6DD),
)

@Composable
fun MusicPlayerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}
