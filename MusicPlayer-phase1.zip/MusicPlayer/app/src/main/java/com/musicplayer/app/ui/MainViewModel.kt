package com.musicplayer.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.musicplayer.app.MusicApp
import com.musicplayer.app.data.Song
import com.musicplayer.app.playback.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(FlowPreview::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as MusicApp).container
    private val repo = container.repository

    val player = PlayerController(app, repo, container.playbackStore)

    val songs: StateFlow<List<Song>> =
        repo.songs.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val query = MutableStateFlow("")
    val scanning = MutableStateFlow(false)
    val scannedOnce = MutableStateFlow(false)

    val visibleSongs: StateFlow<List<Song>> =
        combine(songs, query.debounce(150).onStart { emit("") }) { list, q ->
            val needle = q.trim().lowercase()
            if (needle.isEmpty()) list
            else list.filter {
                it.title.lowercase().contains(needle) ||
                    it.artist.lowercase().contains(needle) ||
                    it.album.lowercase().contains(needle)
            }
        }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var started = false

    /** Called once the audio permission is granted: connects playback and starts library scanning. */
    fun onPermissionGranted() {
        if (started) return
        started = true
        player.connect()
        viewModelScope.launch { runScan() }
        // Automatic re-scan when files are added / removed on the device.
        viewModelScope.launch { repo.mediaChanges().debounce(2_000).collect { runScan() } }
    }

    fun rescan() { viewModelScope.launch { runScan() } }

    private suspend fun runScan() {
        scanning.value = true
        try { repo.scanLibrary() } finally {
            scanning.value = false
            scannedOnce.value = true
        }
    }

    fun toggleFavorite(song: Song) { viewModelScope.launch { repo.toggleFavorite(song) } }
    fun play(list: List<Song>, index: Int) = player.playQueue(list, index)
    fun setQuery(q: String) { query.value = q }

    override fun onCleared() { player.release() }
}
