package com.musicplayer.app.playback

import android.content.ContentUris
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.musicplayer.app.data.Song

private val ALBUM_ART_BASE: Uri = Uri.parse("content://media/external/audio/albumart")

fun Song.artworkUri(): Uri =
    customArtUri?.let(Uri::parse) ?: ContentUris.withAppendedId(ALBUM_ART_BASE, albumId)

fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id.toString())
    .setUri(uri)
    .setMediaMetadata(
        MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(artworkUri())
            .setDurationMs(durationMs)
            .setIsPlayable(true)
            .build()
    )
    .build()
