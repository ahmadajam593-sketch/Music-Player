package com.musicplayer.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

const val SONG_COLUMNS =
    "s.*, COALESCE(t.favorite, 0) AS favorite, COALESCE(t.playCount, 0) AS playCount, " +
        "COALESCE(t.lastPlayed, 0) AS lastPlayed, t.customArtUri AS customArtUri"
const val SONG_SELECT = "SELECT $SONG_COLUMNS FROM songs s LEFT JOIN song_stats t ON t.songId = s.id"

@Dao
interface SongDao {
    @Query("$SONG_SELECT ORDER BY s.title COLLATE NOCASE ASC")
    fun observeAll(): Flow<List<Song>>

    @Query("$SONG_SELECT WHERE t.lastPlayed > 0 ORDER BY t.lastPlayed DESC LIMIT 100")
    fun observeRecent(): Flow<List<Song>>

    @Query("$SONG_SELECT WHERE t.playCount > 0 ORDER BY t.playCount DESC, t.lastPlayed DESC LIMIT 100")
    fun observeMostPlayed(): Flow<List<Song>>

    @Query("$SONG_SELECT WHERE t.favorite = 1 ORDER BY s.title COLLATE NOCASE ASC")
    fun observeFavorites(): Flow<List<Song>>

    @Query("$SONG_SELECT WHERE s.id IN (:ids)")
    suspend fun getByIds(ids: List<Long>): List<Song>

    @Query("SELECT id FROM songs")
    suspend fun getAllIds(): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(songs: List<SongEntity>)

    @Query("DELETE FROM songs WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun ensureStats(stats: SongStatsEntity)

    @Query("UPDATE song_stats SET favorite = :fav WHERE songId = :id")
    suspend fun setFavorite(id: Long, fav: Boolean)

    @Query("UPDATE song_stats SET playCount = playCount + 1, lastPlayed = :now WHERE songId = :id")
    suspend fun incrementPlay(id: Long, now: Long)

    @Query("UPDATE song_stats SET customArtUri = :uri WHERE songId = :id")
    suspend fun setCustomArt(id: Long, uri: String?)
}

@Dao
interface PlaylistDao {
    @Insert suspend fun insert(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :name WHERE id = :id")
    suspend fun rename(id: Long, name: String)

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun delete(id: Long)

    @Query(
        "SELECT p.id AS id, p.name AS name, p.createdAt AS createdAt, " +
            "(SELECT COUNT(*) FROM playlist_songs ps WHERE ps.playlistId = p.id) AS songCount " +
            "FROM playlists p ORDER BY p.createdAt DESC"
    )
    fun observeAll(): Flow<List<PlaylistWithCount>>

    @Query(
        "SELECT $SONG_COLUMNS FROM playlist_songs ps JOIN songs s ON s.id = ps.songId " +
            "LEFT JOIN song_stats t ON t.songId = s.id WHERE ps.playlistId = :playlistId ORDER BY ps.position ASC"
    )
    fun observeSongs(playlistId: Long): Flow<List<Song>>

    @Query("SELECT COALESCE(MAX(position), -1) FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun maxPosition(playlistId: Long): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertLink(link: PlaylistSongEntity)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun removeLink(playlistId: Long, songId: Long)

    @Query("UPDATE playlist_songs SET position = :position WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun setPosition(playlistId: Long, songId: Long, position: Int)
}

@Dao
interface HistoryDao {
    @Insert suspend fun insert(entry: HistoryEntity)

    @Query("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY playedAt DESC LIMIT 1000)")
    suspend fun prune()
}
