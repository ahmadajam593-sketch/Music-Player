package com.musicplayer.app.playback

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.musicplayer.app.data.MusicRepository
import com.musicplayer.app.data.PlaybackStateStore
import com.musicplayer.app.data.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class QueueEntry(val id: Long, val title: String, val artist: String, val artUri: String?)

data class PlayerState(
    val connected: Boolean = false,
    val currentId: Long? = null,
    val title: String = "",
    val artist: String = "",
    val artworkUri: String? = null,
    val showPause: Boolean = false,
    val durationMs: Long = 0L,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val shuffle: Boolean = false,
    val hasNext: Boolean = false,
    val hasPrevious: Boolean = false,
    val queue: List<QueueEntry> = emptyList(),
    val currentIndex: Int = -1,
)

/** App-side handle to the PlaybackService, exposed as a StateFlow for Compose. */
class PlayerController(
    private val context: Context,
    private val repo: MusicRepository,
    private val store: PlaybackStateStore,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null
    private var cachedQueue: List<QueueEntry> = emptyList()

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    /** Ticks only while collected by lifecycle-aware UI, so it costs nothing in the background. */
    val positionFlow: Flow<Long> = flow {
        while (true) {
            emit(controller?.currentPosition?.coerceAtLeast(0) ?: 0L)
            delay(500)
        }
    }

    fun connect() {
        if (future != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val f = MediaController.Builder(context, token).buildAsync()
        future = f
        f.addListener({
            val c = try { f.get() } catch (e: Exception) { future = null; return@addListener }
            controller = c
            c.addListener(listener)
            scope.launch {
                restoreIfEmpty(c)
                refresh(c, rebuildQueue = true)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private suspend fun restoreIfEmpty(c: MediaController) {
        if (c.mediaItemCount > 0) return
        val saved = store.load() ?: return
        val songs = withContext(Dispatchers.IO) { repo.getSongsByIds(saved.ids) }
        if (songs.isEmpty() || c.mediaItemCount > 0) return
        val idx = songs.indexOfFirst { it.id == saved.currentId }
        c.setMediaItems(songs.map { it.toMediaItem() }, idx.coerceAtLeast(0), if (idx >= 0) saved.positionMs else 0L)
        c.repeatMode = saved.repeat
        c.shuffleModeEnabled = saved.shuffle
        c.prepare() // ready to resume, but not auto-playing
    }

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refresh(player, events.contains(Player.EVENT_TIMELINE_CHANGED))
        }
    }

    private fun refresh(p: Player, rebuildQueue: Boolean) {
        if (rebuildQueue) {
            cachedQueue = (0 until p.mediaItemCount).map { i ->
                val item = p.getMediaItemAt(i)
                QueueEntry(
                    id = item.mediaId.toLongOrNull() ?: -1,
                    title = item.mediaMetadata.title?.toString().orEmpty(),
                    artist = item.mediaMetadata.artist?.toString().orEmpty(),
                    artUri = item.mediaMetadata.artworkUri?.toString(),
                )
            }
        }
        val item = p.currentMediaItem
        val md = item?.mediaMetadata
        val duration = p.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: md?.durationMs ?: 0L
        _state.update {
            PlayerState(
                connected = true,
                currentId = item?.mediaId?.toLongOrNull(),
                title = md?.title?.toString().orEmpty(),
                artist = md?.artist?.toString().orEmpty(),
                artworkUri = md?.artworkUri?.toString(),
                showPause = p.playWhenReady &&
                    p.playbackState != Player.STATE_ENDED && p.playbackState != Player.STATE_IDLE,
                durationMs = duration,
                repeatMode = p.repeatMode,
                shuffle = p.shuffleModeEnabled,
                hasNext = p.hasNextMediaItem(),
                hasPrevious = p.hasPreviousMediaItem(),
                queue = cachedQueue,
                currentIndex = p.currentMediaItemIndex,
            )
        }
    }

    // ---- Commands ----
    fun playQueue(songs: List<Song>, startIndex: Int) {
        val c = controller ?: return
        if (songs.isEmpty()) return
        c.setMediaItems(songs.map { it.toMediaItem() }, startIndex.coerceIn(songs.indices), 0L)
        c.prepare()
        c.play()
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.playWhenReady && c.playbackState != Player.STATE_ENDED && c.playbackState != Player.STATE_IDLE) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0, 0L)
            c.play()
        }
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPrevious() }
    fun seekTo(positionMs: Long) { controller?.seekTo(positionMs) }
    fun seekToIndex(index: Int) { controller?.seekTo(index, 0L) }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }

    fun playNext(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) playQueue(listOf(song), 0)
        else c.addMediaItem(c.currentMediaItemIndex + 1, song.toMediaItem())
    }

    fun addToQueue(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) playQueue(listOf(song), 0) else c.addMediaItem(song.toMediaItem())
    }

    fun removeFromQueue(index: Int) { controller?.removeMediaItem(index) }
    fun moveQueueItem(from: Int, to: Int) { controller?.moveMediaItem(from, to) }

    fun release() {
        scope.cancel()
        controller?.removeListener(listener)
        future?.let { MediaController.releaseFuture(it) }
        controller = null
        future = null
    }
}
