# Music Player (Android) — Phase 1: Core

Kotlin · Jetpack Compose · Media3 ExoPlayer · Room · MediaStore.

## Build the APK
**GitHub (no local setup):** push this folder to a GitHub repo → Actions → "Build APK" → download
the `MusicPlayer-apk` artifact → install `app-release.apk`.

**Android Studio:** open the folder, accept "use default Gradle wrapper" if asked, then
Build → Build Bundle(s)/APK(s) → Build APK(s).

## Phase 1 includes
- MediaStore scanning of real audio files (+ auto rescan on library changes)
- Room DB: songs, stats (favorites / play counts), playlists, history
- Media3 playback service: notification, lock screen, Bluetooth/headset buttons, audio focus
- Queue + position saved and restored (also via headset button after app was killed)
- Songs list, search, favorites, mini-player
