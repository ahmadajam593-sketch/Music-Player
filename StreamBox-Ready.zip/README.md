# StreamBox (Android)

Movies, TV shows and anime browser. Kotlin + Jetpack Compose. Module: `app`.
Sources: TMDB, TVmaze, Jikan (MyAnimeList), OMDb. No streaming links.

## API keys (free)
TMDB (movies) and OMDb (ratings, optional) need a key: open the app -> Settings and paste it.
Keys are stored only on the phone. TVmaze and Jikan need no key.

## Build
GitHub Actions builds `./gradlew assembleDebug` -> artifact `StreamBox-debug-apk`.
