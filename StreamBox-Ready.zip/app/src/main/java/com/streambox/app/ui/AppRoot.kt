package com.streambox.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    val stack by vm.stack.collectAsStateWithLifecycle()
    val homeState = rememberLazyListState()
    BackHandler(enabled = stack.size > 1) { vm.back() }

    Box(Modifier.fillMaxSize().background(Brand.bg).systemBarsPadding()) {
        AnimatedContent(
            targetState = stack.last(),
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(150)) },
            label = "nav",
        ) { screen ->
            when (screen) {
                is Screen.Home -> HomeScreen(vm, homeState)
                is Screen.Category -> CategoryScreen(vm, screen)
                is Screen.Search -> SearchScreen(vm)
                is Screen.Details -> DetailsScreen(vm, screen.item)
                is Screen.Seasons -> SeasonsScreen(vm, screen.item)
                is Screen.Favorites -> SavedScreen(
                    title = "المفضلة", items = vm.favorites, emptyText = "لم تضف أي عنوان إلى المفضلة بعد",
                    vm = vm, onRemove = vm::removeFavorite,
                )
                is Screen.Watchlist -> SavedScreen(
                    title = "قائمة المشاهدة", items = vm.watchlist, emptyText = "قائمة المشاهدة فارغة",
                    vm = vm, onRemove = vm::removeWatchlist,
                )
                is Screen.Genres -> GenresScreen(vm)
                is Screen.Settings -> SettingsScreen(vm)
            }
        }
    }
}
