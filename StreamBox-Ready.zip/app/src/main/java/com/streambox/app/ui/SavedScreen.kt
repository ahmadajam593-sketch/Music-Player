package com.streambox.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.streambox.app.data.MediaItem
import kotlinx.coroutines.flow.StateFlow

/** Shared screen for Favorites and Watchlist. */
@Composable
fun SavedScreen(
    title: String,
    items: StateFlow<List<MediaItem>>,
    emptyText: String,
    vm: AppViewModel,
    onRemove: (MediaItem) -> Unit,
) {
    val list by items.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        TopBar("$title (${list.size})", onBack = vm::back)
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(emptyText, color = Brand.muted)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(116.dp),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                items(list, key = { it.key }) { item ->
                    PosterCard(
                        item,
                        onClick = { vm.navigate(Screen.Details(item)) },
                        onRemove = { onRemove(item) },
                    )
                }
            }
        }
    }
}
