package com.streambox.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class HttpException(val code: Int, message: String) : Exception(message)

object Http {
    suspend fun get(url: String, headers: Map<String, String> = emptyMap()): String {
        var attempt = 0
        while (true) {
            try {
                return request(url, headers)
            } catch (e: HttpException) {
                // Rate limited (Jikan allows ~3 requests/second): wait and retry once.
                if (e.code == 429 && attempt == 0) {
                    attempt++
                    delay(1300)
                } else throw e
            }
        }
    }

    private suspend fun request(url: String, headers: Map<String, String>): String = withContext(Dispatchers.IO) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000
            conn.requestMethod = "GET"
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("User-Agent", "StreamBox/1.0 (Android)")
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            val code = conn.responseCode
            if (code in 200..299) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else {
                throw HttpException(code, "HTTP $code")
            }
        } finally {
            conn.disconnect()
        }
    }
}

/** Small file cache for API responses, so lists open instantly and work briefly offline. */
class DiskCache(context: Context) {
    private val dir = File(context.cacheDir, "api").apply { mkdirs() }

    private fun file(key: String) = File(dir, MessageDigest.getInstance("SHA-1")
        .digest(key.toByteArray()).joinToString("") { "%02x".format(it) })

    /** Returns (savedAtMillis, body) or null. */
    fun get(key: String): Pair<Long, String>? {
        val f = file(key)
        if (!f.exists()) return null
        val text = runCatching { f.readText() }.getOrNull() ?: return null
        val nl = text.indexOf('\n')
        if (nl < 0) return null
        val t = text.substring(0, nl).toLongOrNull() ?: return null
        return t to text.substring(nl + 1)
    }

    fun put(key: String, body: String) {
        runCatching { file(key).writeText("${System.currentTimeMillis()}\n$body") }
    }

    fun clear() {
        dir.listFiles()?.forEach { it.delete() }
    }
}
