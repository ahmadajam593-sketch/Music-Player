package com.streambox.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.streambox.app.data.MediaType

@Composable
fun SearchScreen(vm: AppViewModel) {
    val st by vm.search.collectAsStateWithLifecycle()
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    Column(Modifier.fillMaxSize()) {
        TopBar("بحث", onBack = vm::back)
        OutlinedTextField(
            value = st.query,
            onValueChange = vm::setQuery,
            singleLine = true,
            placeholder = { Text("ابحث عن فيلم أو مسلسل أو أنمي") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = {
                if (st.query.isNotEmpty()) IconButton({ vm.setQuery("") }) { Icon(Icons.Rounded.Close, "مسح") }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Brand.card, unfocusedContainerColor = Brand.card,
                focusedBorderColor = Brand.accent, unfocusedBorderColor = Color.Transparent,
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                cursorColor = Brand.accent,
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).focusRequester(focus),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item { Pill("الكل", selected = st.typeFilter == null) { vm.setSearchType(null) } }
            items(MediaType.values().toList()) { t ->
                Pill(t.labelAr, selected = st.typeFilter == t) { vm.setSearchType(t) }
            }
        }
        if (st.warnings.isNotEmpty() && st.items.isNotEmpty()) {
            Text(
                "تعذّر الوصول إلى: ${st.warnings.joinToString("، ")}. النتائج من المصادر الأخرى.",
                color = Brand.muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp),
            )
        }
        Box(Modifier.fillMaxSize()) {
            when {
                st.loading -> CenterLoading()
                st.error != null -> ErrorBox(st.error!!, onRetry = { vm.setQuery(st.query) })
                st.query.trim().length < 2 -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("اكتب حرفين على الأقل للبحث في كل المصادر", color = Brand.muted)
                }
                st.items.isEmpty() -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("لا توجد نتائج لـ \"${st.query}\"", color = Brand.muted)
                }
                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(116.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(st.items, key = { it.key }) { item ->
                        PosterCard(item, onClick = { vm.navigate(Screen.Details(item)) })
                    }
                }
            }
        }
    }
}
