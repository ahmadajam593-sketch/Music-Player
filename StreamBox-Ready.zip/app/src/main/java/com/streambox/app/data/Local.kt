package com.streambox.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

/** A favorite or watchlist entry. [json] is a full snapshot of the MediaItem. */
@Entity(tableName = "saved", primaryKeys = ["itemKey", "listType"])
data class SavedEntity(val itemKey: String, val listType: String, val json: String, val addedAt: Long)

@Dao
interface SavedDao {
    @Query("SELECT * FROM saved WHERE listType = :list ORDER BY addedAt DESC")
    fun observe(list: String): Flow<List<SavedEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: SavedEntity)

    @Query("DELETE FROM saved WHERE itemKey = :key AND listType = :list")
    suspend fun remove(key: String, list: String)
}

@Database(entities = [SavedEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun savedDao(): SavedDao
}
