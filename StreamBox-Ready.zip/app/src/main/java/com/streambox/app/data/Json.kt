package com.streambox.app.data

import org.json.JSONArray
import org.json.JSONObject

fun JSONObject.str(name: String): String? {
    if (!has(name) || isNull(name)) return null
    val v = optString(name).trim()
    return if (v.isEmpty() || v == "null" || v == "N/A") null else v
}

fun JSONObject.dbl(name: String): Double? {
    if (!has(name) || isNull(name)) return null
    val d = optDouble(name)
    return if (d.isNaN()) null else d
}

fun JSONObject.intOrNull(name: String): Int? {
    if (!has(name) || isNull(name)) return null
    val d = optDouble(name)
    return if (d.isNaN()) null else d.toInt()
}

fun JSONArray.objects(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }

fun JSONArray.strings(): List<String> =
    (0 until length()).mapNotNull { i -> optString(i).takeIf { s -> s.isNotBlank() } }
