package com.streambox.app.data

/** One metadata provider. Add a new subclass + register it in Repository to add a source. */
abstract class MediaSource(protected val settings: Settings) {
    abstract val id: String
    abstract val displayName: String

    /** Key inside MediaItem.ids that identifies an item for this source. */
    abstract val idKey: String
    open val requiresKey: Boolean = false
    open val providesFeeds: Boolean = true

    open fun hasCredentials(): Boolean = true
    abstract fun supports(type: MediaType): Boolean

    fun isConfigured(): Boolean = settings.isEnabled(id) && hasCredentials()

    open suspend fun feed(type: MediaType, feed: Feed, page: Int, genre: Genre?): List<MediaItem> = emptyList()
    open suspend fun search(query: String, type: MediaType?): List<MediaItem> = emptyList()
    open suspend fun details(item: MediaItem): Details? = null
    open suspend fun episodes(item: MediaItem, season: Int): List<Episode> = emptyList()
}
