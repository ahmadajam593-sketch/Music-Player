package com.streambox.app.data

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject
import java.net.URLEncoder
import java.time.LocalDate
import java.util.Locale

/** TMDB (themoviedb.org): movies + TV. Needs a free API key (v3 key or v4 read token). */
class TmdbSource(settings: Settings) : MediaSource(settings) {
    override val id = "tmdb"
    override val displayName = "TMDB"
    override val idKey = "tmdb"
    override val requiresKey = true
    override fun hasCredentials() = settings.tmdbKey.isNotBlank()
    override fun supports(type: MediaType) = type != MediaType.ANIME

    private val base = "https://api.themoviedb.org/3"

    private suspend fun call(
        path: String,
        params: Map<String, String> = emptyMap(),
        language: String = settings.tmdbLanguage(),
    ): JSONObject {
        val key = settings.tmdbKey
        val bearer = key.startsWith("eyJ")
        val q = StringBuilder("language=").append(enc(language))
        params.forEach { (k, v) -> q.append('&').append(k).append('=').append(enc(v)) }
        if (!bearer) q.append("&api_key=").append(enc(key))
        val headers = if (bearer) mapOf("Authorization" to "Bearer $key") else emptyMap()
        return JSONObject(Http.get("$base/$path?$q", headers))
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun img(path: String?, size: String): String? =
        path?.let { "https://image.tmdb.org/t/p/$size$it" }

    private fun parse(o: JSONObject, type: MediaType): MediaItem? {
        val tid = o.optLong("id", -1)
        if (tid < 0) return null
        val title = o.str("title") ?: o.str("name") ?: return null
        val date = o.str("release_date") ?: o.str("first_air_date")
        val genres = o.optJSONArray("genre_ids")?.let { arr ->
            (0 until arr.length()).mapNotNull { tmdbGenreNames[arr.optInt(it)] }
        } ?: emptyList()
        return MediaItem(
            key = "tmdb:${type.name}:$tid",
            type = type,
            title = title,
            originalTitle = o.str("original_title") ?: o.str("original_name"),
            year = date?.take(4),
            poster = img(o.str("poster_path"), "w342"),
            backdrop = img(o.str("backdrop_path"), "w780"),
            rating = o.dbl("vote_average")?.takeIf { it > 0 },
            overview = o.str("overview"),
            genres = genres,
            source = id,
            ids = mapOf("tmdb" to tid.toString()),
        )
    }

    override suspend fun feed(type: MediaType, feed: Feed, page: Int, genre: Genre?): List<MediaItem> {
        val isMovie = type == MediaType.MOVIE
        val kind = if (isMovie) "movie" else "tv"
        val gid = genre?.let { if (isMovie) it.tmdbMovie else it.tmdbTv }
        if (genre != null && gid == null) return emptyList()
        val today = LocalDate.now().toString()

        val endpoint: String
        val params = mutableMapOf("page" to page.toString())
        if (gid != null) {
            endpoint = "discover/$kind"
            params["with_genres"] = gid.toString()
            when (feed) {
                Feed.TRENDING -> params["sort_by"] = "popularity.desc"
                Feed.POPULAR -> { params["sort_by"] = "vote_average.desc"; params["vote_count.gte"] = "500" }
                Feed.LATEST -> {
                    if (isMovie) {
                        params["sort_by"] = "primary_release_date.desc"
                        params["primary_release_date.lte"] = today
                    } else {
                        params["sort_by"] = "first_air_date.desc"
                        params["first_air_date.lte"] = today
                    }
                    params["vote_count.gte"] = "20"
                }
            }
        } else {
            endpoint = when (feed) {
                Feed.TRENDING -> "trending/$kind/week"
                Feed.POPULAR -> "$kind/popular"
                Feed.LATEST -> if (isMovie) "movie/now_playing" else "tv/on_the_air"
            }
        }
        return call(endpoint, params).optJSONArray("results")?.objects()
            ?.mapNotNull { parse(it, type) } ?: emptyList()
    }

    override suspend fun search(query: String, type: MediaType?): List<MediaItem> = coroutineScope {
        val types = when (type) {
            null -> listOf(MediaType.MOVIE, MediaType.TV)
            MediaType.ANIME -> emptyList()
            else -> listOf(type)
        }
        types.map { t ->
            async {
                val kind = if (t == MediaType.MOVIE) "movie" else "tv"
                call("search/$kind", mapOf("query" to query, "page" to "1", "include_adult" to "false"))
                    .optJSONArray("results")?.objects()?.mapNotNull { parse(it, t) } ?: emptyList()
            }
        }.awaitAll().flatten()
    }

    override suspend fun details(item: MediaItem): Details? {
        val tid = item.ids["tmdb"] ?: return null
        val isMovie = item.type == MediaType.MOVIE
        val kind = if (isMovie) "movie" else "tv"
        val o = call("$kind/$tid", mapOf("append_to_response" to "credits,videos,external_ids,watch/providers"))

        var overview = o.str("overview")
        var tagline = o.str("tagline")
        if (overview == null && settings.tmdbLanguage() != "en-US") {
            val en = runCatching { call("$kind/$tid", language = "en-US") }.getOrNull()
            if (en != null) {
                overview = en.str("overview")
                if (tagline == null) tagline = en.str("tagline")
            }
        }

        val genres = o.optJSONArray("genres")?.objects()?.mapNotNull { it.str("name") } ?: item.genres
        val imdb = o.str("imdb_id") ?: o.optJSONObject("external_ids")?.str("imdb_id")
        val cast = o.optJSONObject("credits")?.optJSONArray("cast")?.objects()
            ?.take(12)?.mapNotNull { it.str("name") } ?: emptyList()

        val trailer = o.optJSONObject("videos")?.optJSONArray("results")?.objects()
            ?.filter { it.str("site") == "YouTube" && it.str("key") != null }
            ?.sortedByDescending { v ->
                (if (v.str("type") == "Trailer") 2 else 0) + (if (v.optBoolean("official")) 1 else 0)
            }
            ?.firstOrNull()?.str("key")?.let { "https://www.youtube.com/watch?v=$it" }

        val region = Locale.getDefault().country.ifBlank { "US" }
        val providers = o.optJSONObject("watch/providers")?.optJSONObject("results")
            ?.optJSONObject(region)?.optJSONArray("flatrate")?.objects()
            ?.mapNotNull { it.str("provider_name") } ?: emptyList()

        val seasons = o.optJSONArray("seasons")?.objects()
            ?.filter { (it.intOrNull("season_number") ?: 0) > 0 }
            ?.map { s ->
                val n = s.intOrNull("season_number") ?: 0
                SeasonInfo(
                    number = n,
                    name = s.str("name") ?: "الموسم $n",
                    episodeCount = s.intOrNull("episode_count") ?: 0,
                    year = s.str("air_date")?.take(4),
                    poster = img(s.str("poster_path"), "w185"),
                )
            } ?: emptyList()

        val runtimeMin = if (isMovie) o.intOrNull("runtime")
        else o.optJSONArray("episode_run_time")?.optInt(0)?.takeIf { it > 0 }
        val facts = buildList {
            o.str("status")?.let { add("الحالة" to it) }
            o.str("original_language")?.let { add("اللغة الأصلية" to it.uppercase()) }
            o.intOrNull("number_of_seasons")?.let { add("عدد المواسم" to it.toString()) }
            o.intOrNull("number_of_episodes")?.let { add("عدد الحلقات" to it.toString()) }
        }

        val full = item.copy(
            overview = overview ?: item.overview,
            genres = genres,
            backdrop = img(o.str("backdrop_path"), "w1280") ?: item.backdrop,
            poster = img(o.str("poster_path"), "w500") ?: item.poster,
            rating = o.dbl("vote_average")?.takeIf { it > 0 } ?: item.rating,
            ids = if (imdb != null) item.ids + ("imdb" to imdb) else item.ids,
        )
        return Details(
            item = full, sourceId = id, tagline = tagline,
            runtime = runtimeMin?.let { "$it دقيقة" },
            cast = cast, trailerUrl = trailer, providers = providers,
            seasons = seasons, facts = facts,
        )
    }

    override suspend fun episodes(item: MediaItem, season: Int): List<Episode> {
        val tid = item.ids["tmdb"] ?: return emptyList()
        val o = call("tv/$tid/season/$season")
        return o.optJSONArray("episodes")?.objects()?.map { e ->
            Episode(
                number = e.intOrNull("episode_number") ?: 0,
                name = e.str("name") ?: "",
                overview = e.str("overview"),
                airDate = e.str("air_date"),
                runtime = e.intOrNull("runtime"),
                image = img(e.str("still_path"), "w300"),
                rating = e.dbl("vote_average")?.takeIf { v -> v > 0 },
            )
        } ?: emptyList()
    }
}
