package com.streambox.app.data

import org.json.JSONObject
import java.net.URLEncoder
import kotlin.math.max

/** Jikan (unofficial MyAnimeList API): anime. Free, no API key. */
class JikanSource(settings: Settings) : MediaSource(settings) {
    override val id = "jikan"
    override val displayName = "Jikan"
    override val idKey = "mal"
    override fun supports(type: MediaType) = type == MediaType.ANIME

    private val base = "https://api.jikan.moe/v4"

    private fun parse(o: JSONObject): MediaItem? {
        val mal = o.optLong("mal_id", -1)
        if (mal < 0) return null
        val title = o.str("title_english") ?: o.str("title") ?: return null
        val images = o.optJSONObject("images")?.optJSONObject("jpg")
        val year = o.intOrNull("year")?.toString()
            ?: o.optJSONObject("aired")?.optJSONObject("prop")?.optJSONObject("from")?.intOrNull("year")?.toString()
        return MediaItem(
            key = "jikan:ANIME:$mal",
            type = MediaType.ANIME,
            title = title,
            originalTitle = o.str("title"),
            year = year,
            poster = images?.str("large_image_url") ?: images?.str("image_url"),
            backdrop = images?.str("large_image_url"),
            rating = o.dbl("score")?.takeIf { it > 0 },
            overview = o.str("synopsis"),
            genres = o.optJSONArray("genres")?.objects()?.mapNotNull { it.str("name") }
                ?.map { genreArabic(it) } ?: emptyList(),
            source = id,
            ids = mapOf("mal" to mal.toString()),
        )
    }

    override suspend fun feed(type: MediaType, feed: Feed, page: Int, genre: Genre?): List<MediaItem> {
        val gid = genre?.jikan
        if (genre != null && gid == null) return emptyList()
        val url = if (gid != null) {
            val order = when (feed) {
                Feed.TRENDING -> "order_by=popularity&sort=asc"
                Feed.POPULAR -> "order_by=score&sort=desc&min_score=7"
                Feed.LATEST -> "order_by=start_date&sort=desc&status=airing"
            }
            "$base/anime?genres=$gid&$order&sfw=true&limit=24&page=$page"
        } else {
            val ep = when (feed) {
                Feed.TRENDING -> "top/anime?filter=airing"
                Feed.POPULAR -> "top/anime?filter=bypopularity"
                Feed.LATEST -> "seasons/now?"
            }
            "$base/$ep&sfw=true&limit=24&page=$page"
        }
        return JSONObject(Http.get(url)).optJSONArray("data")?.objects()?.mapNotNull { parse(it) } ?: emptyList()
    }

    override suspend fun search(query: String, type: MediaType?): List<MediaItem> {
        if (type != null && type != MediaType.ANIME) return emptyList()
        val url = "$base/anime?q=${URLEncoder.encode(query, "UTF-8")}&limit=15&sfw=true"
        return JSONObject(Http.get(url)).optJSONArray("data")?.objects()?.mapNotNull { parse(it) } ?: emptyList()
    }

    override suspend fun details(item: MediaItem): Details? {
        val mal = item.ids["mal"] ?: return null
        val o = JSONObject(Http.get("$base/anime/$mal/full")).optJSONObject("data") ?: return null
        val parsed = parse(o) ?: return null
        val eps = o.intOrNull("episodes")
        val chunks = if (eps == null || eps <= 0) 1 else (eps + 99) / 100
        val seasons = (1..max(1, chunks)).map { p ->
            val from = (p - 1) * 100 + 1
            val to = if (eps != null && eps > 0) minOf(p * 100, eps) else null
            SeasonInfo(
                number = p,
                name = if (to != null) "الحلقات $from-$to" else "الحلقات",
                episodeCount = if (to != null) to - from + 1 else 0,
                year = null, poster = null,
            )
        }
        val studios = o.optJSONArray("studios")?.objects()?.mapNotNull { it.str("name") }?.joinToString("، ")
        val facts = buildList {
            o.str("status")?.let { add("الحالة" to it) }
            o.str("type")?.let { add("النوع" to it) }
            eps?.let { add("عدد الحلقات" to it.toString()) }
            o.str("duration")?.let { add("مدة الحلقة" to it) }
            o.optJSONObject("aired")?.str("string")?.let { add("فترة العرض" to it) }
            studios?.takeIf { it.isNotBlank() }?.let { add("الاستوديو" to it) }
            o.intOrNull("rank")?.let { add("الترتيب على MAL" to "#$it") }
        }
        val providers = o.optJSONArray("streaming")?.objects()?.mapNotNull { it.str("name") } ?: emptyList()
        return Details(
            item = item.copy(
                overview = parsed.overview ?: item.overview,
                genres = parsed.genres.ifEmpty { item.genres },
                rating = parsed.rating ?: item.rating,
            ),
            sourceId = id,
            runtime = o.str("duration"),
            trailerUrl = o.optJSONObject("trailer")?.str("url"),
            providers = providers,
            seasons = seasons,
            facts = facts,
        )
    }

    /** For anime, [season] is the page number (100 episodes per page). */
    override suspend fun episodes(item: MediaItem, season: Int): List<Episode> {
        val mal = item.ids["mal"] ?: return emptyList()
        return JSONObject(Http.get("$base/anime/$mal/episodes?page=$season")).optJSONArray("data")?.objects()
            ?.map { e ->
                Episode(
                    number = e.intOrNull("mal_id") ?: 0,
                    name = e.str("title") ?: "",
                    overview = null,
                    airDate = e.str("aired")?.take(10),
                    runtime = null,
                    image = null,
                    rating = e.dbl("score")?.takeIf { it > 0 },
                )
            } ?: emptyList()
    }
}
