package com.streambox.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.streambox.app.data.AppDatabase
import com.streambox.app.data.DiskCache
import com.streambox.app.data.Details
import com.streambox.app.data.Episode
import com.streambox.app.data.Feed
import com.streambox.app.data.Genre
import com.streambox.app.data.HttpException
import com.streambox.app.data.MediaItem
import com.streambox.app.data.MediaType
import com.streambox.app.data.NoSourceException
import com.streambox.app.data.Repository
import com.streambox.app.data.SavedEntity
import com.streambox.app.data.Settings
import com.streambox.app.data.SourceStatus
import com.streambox.app.data.mediaItemFromJson
import com.streambox.app.data.toJson
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.IOException
import java.net.UnknownHostException

sealed interface Screen {
    data object Home : Screen
    data class Category(val type: MediaType, val feed: Feed = Feed.TRENDING, val genre: Genre? = null) : Screen
    data object Search : Screen
    data class Details(val item: MediaItem) : Screen
    data class Seasons(val item: MediaItem) : Screen
    data object Favorites : Screen
    data object Watchlist : Screen
    data object Genres : Screen
    data object Settings : Screen
}

data class FeedKey(val type: MediaType, val feed: Feed, val genre: Genre? = null)

data class FeedState(
    val loading: Boolean = false,
    val items: List<MediaItem> = emptyList(),
    val error: String? = null,
    val needsKey: Boolean = false,
    val updatedAt: Long = 0L,
    val page: Int = 1,
    val endReached: Boolean = false,
    val warnings: List<String> = emptyList(),
)

data class SearchState(
    val query: String = "",
    val typeFilter: MediaType? = null,
    val loading: Boolean = false,
    val items: List<MediaItem> = emptyList(),
    val error: String? = null,
    val warnings: List<String> = emptyList(),
)

data class DetailsState(
    val item: MediaItem? = null,
    val loading: Boolean = false,
    val details: Details? = null,
    val error: String? = null,
)

data class EpisodesState(
    val loading: Boolean = false,
    val episodes: List<Episode> = emptyList(),
    val error: String? = null,
)

fun Throwable.userMessage(): String = when (this) {
    is NoSourceException -> message ?: "لا يوجد مصدر مفعّل"
    is HttpException -> when (code) {
        401, 403 -> "مفتاح API غير صالح. راجع الإعدادات"
        404 -> "المحتوى غير موجود"
        429 -> "تم تجاوز حد الطلبات. حاول بعد قليل"
        else -> "تعذّر الاتصال بالمصدر (HTTP $code)"
    }
    is UnknownHostException -> "لا يوجد اتصال بالإنترنت"
    is IOException -> "تعذّر تحميل البيانات. تحقق من الاتصال"
    else -> "حدث خطأ غير متوقع"
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val settings = Settings(app)
    private val cache = DiskCache(app)
    private val repo = Repository(settings, cache)
    private val dao = Room.databaseBuilder(app, AppDatabase::class.java, "streambox.db").build().savedDao()

    // ---------- navigation ----------
    private val _stack = MutableStateFlow<List<Screen>>(listOf(Screen.Home))
    val stack: StateFlow<List<Screen>> = _stack.asStateFlow()
    fun navigate(s: Screen) { _stack.update { it + s } }
    fun back() { _stack.update { if (it.size > 1) it.dropLast(1) else it } }

    // ---------- saved lists ----------
    private fun savedFlow(list: String) = dao.observe(list)
        .map { rows -> rows.mapNotNull { r -> runCatching { mediaItemFromJson(JSONObject(r.json)) }.getOrNull() } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val favorites: StateFlow<List<MediaItem>> = savedFlow("fav")
    val watchlist: StateFlow<List<MediaItem>> = savedFlow("watch")
    val favKeys: StateFlow<Set<String>> =
        favorites.map { l -> l.map { it.key }.toSet() }.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())
    val watchKeys: StateFlow<Set<String>> =
        watchlist.map { l -> l.map { it.key }.toSet() }.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    fun toggleFavorite(item: MediaItem) = toggle("fav", item, favKeys.value)
    fun toggleWatchlist(item: MediaItem) = toggle("watch", item, watchKeys.value)
    fun removeFavorite(item: MediaItem) { viewModelScope.launch { dao.remove(item.key, "fav") } }
    fun removeWatchlist(item: MediaItem) { viewModelScope.launch { dao.remove(item.key, "watch") } }

    private fun toggle(list: String, item: MediaItem, keys: Set<String>) {
        viewModelScope.launch {
            if (item.key in keys) dao.remove(item.key, list)
            else dao.upsert(SavedEntity(item.key, list, item.toJson().toString(), System.currentTimeMillis()))
        }
    }

    // ---------- feeds ----------
    private val _feeds = MutableStateFlow<Map<FeedKey, FeedState>>(emptyMap())
    val feeds: StateFlow<Map<FeedKey, FeedState>> = _feeds.asStateFlow()
    private val jobs = HashMap<FeedKey, Job>()
    val settingsVersion = MutableStateFlow(0)

    private fun update(key: FeedKey, f: (FeedState) -> FeedState) {
        _feeds.update { m -> m + (key to f(m[key] ?: FeedState())) }
    }

    fun load(key: FeedKey, force: Boolean = false) {
        val cur = _feeds.value[key]
        if (!force && cur != null && (cur.items.isNotEmpty() || cur.loading)) return
        jobs[key]?.cancel()
        jobs[key] = viewModelScope.launch { fetch(key, 1, force) }
    }

    fun loadMore(key: FeedKey) {
        val cur = _feeds.value[key] ?: return
        if (cur.loading || cur.endReached || cur.items.isEmpty()) return
        jobs[key] = viewModelScope.launch { fetch(key, cur.page + 1, false) }
    }

    fun refreshType(type: MediaType) {
        Feed.values().forEach { load(FeedKey(type, it), force = true) }
    }

    private suspend fun fetch(key: FeedKey, page: Int, force: Boolean) {
        update(key) { it.copy(loading = true, error = null, needsKey = false) }
        try {
            val r = repo.feed(key.type, key.feed, page, key.genre, force)
            update(key) { old ->
                val items = if (page == 1) r.items else (old.items + r.items).distinctBy { it.key }
                old.copy(
                    loading = false, items = items, updatedAt = if (page == 1) r.updatedAt else old.updatedAt,
                    page = page, endReached = r.items.isEmpty(), warnings = r.warnings, error = null,
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: NoSourceException) {
            update(key) { it.copy(loading = false, needsKey = true, error = e.message) }
        } catch (e: Exception) {
            update(key) { it.copy(loading = false, error = e.userMessage()) }
        }
    }

    // ---------- search ----------
    private val _search = MutableStateFlow(SearchState())
    val search: StateFlow<SearchState> = _search.asStateFlow()
    private var searchJob: Job? = null

    fun setQuery(q: String) { _search.update { it.copy(query = q) }; runSearch() }
    fun setSearchType(t: MediaType?) { _search.update { it.copy(typeFilter = t) }; runSearch() }

    private fun runSearch() {
        searchJob?.cancel()
        val s = _search.value
        val q = s.query.trim()
        if (q.length < 2) {
            _search.update { it.copy(loading = false, items = emptyList(), error = null, warnings = emptyList()) }
            return
        }
        searchJob = viewModelScope.launch {
            delay(400)
            _search.update { it.copy(loading = true, error = null) }
            try {
                val r = repo.search(q, s.typeFilter)
                _search.update { it.copy(loading = false, items = r.items, warnings = r.warnings, error = null) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _search.update { it.copy(loading = false, items = emptyList(), error = e.userMessage()) }
            }
        }
    }

    // ---------- details & episodes ----------
    private val _details = MutableStateFlow(DetailsState())
    val detailsState: StateFlow<DetailsState> = _details.asStateFlow()
    private var detailsJob: Job? = null

    fun loadDetails(item: MediaItem, force: Boolean = false) {
        val cur = _details.value
        if (!force && cur.item?.key == item.key && (cur.details != null || cur.loading)) return
        detailsJob?.cancel()
        _details.value = DetailsState(item = item, loading = true)
        detailsJob = viewModelScope.launch {
            try {
                val d = repo.details(item)
                _details.value = DetailsState(item = item, details = d)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _details.value = DetailsState(item = item, error = e.userMessage())
            }
        }
    }

    private val _episodes = MutableStateFlow<Map<String, EpisodesState>>(emptyMap())
    val episodes: StateFlow<Map<String, EpisodesState>> = _episodes.asStateFlow()

    fun loadEpisodes(item: MediaItem, season: Int, force: Boolean = false) {
        val k = "${item.key}#$season"
        val cur = _episodes.value[k]
        if (!force && cur != null && (cur.episodes.isNotEmpty() || cur.loading)) return
        val sourceId = _details.value.details?.takeIf { it.item.key == item.key }?.sourceId ?: item.source
        _episodes.update { it + (k to EpisodesState(loading = true)) }
        viewModelScope.launch {
            try {
                val list = repo.episodes(item, season, sourceId)
                _episodes.update { it + (k to EpisodesState(episodes = list)) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _episodes.update { it + (k to EpisodesState(error = e.userMessage())) }
            }
        }
    }

    // ---------- settings ----------
    fun moviesAvailable() = repo.isAvailable(MediaType.MOVIE)
    fun sourceStatuses(): List<SourceStatus> = repo.statuses()
    fun activeSourcesLine(): String = repo.activeNames().joinToString(" • ")

    fun defaultTypeFor(genre: Genre): MediaType =
        listOf(MediaType.MOVIE, MediaType.TV, MediaType.ANIME)
            .firstOrNull { genre.supports(it) && (it != MediaType.MOVIE || moviesAvailable()) }
            ?: MediaType.TV

    fun saveKeys(tmdb: String, omdb: String) {
        settings.tmdbKey = tmdb
        settings.omdbKey = omdb
        settingsChanged()
    }

    fun setLanguage(lang: String) { settings.contentLang = lang; settingsChanged() }
    fun setSourceEnabled(id: String, enabled: Boolean) { settings.setEnabled(id, enabled); settingsChanged() }
    fun clearCache() { cache.clear(); settingsChanged() }

    private fun settingsChanged() {
        jobs.values.forEach { it.cancel() }
        jobs.clear()
        _feeds.value = emptyMap()
        _episodes.value = emptyMap()
        _details.value = DetailsState()
        settingsVersion.update { it + 1 }
    }
}
