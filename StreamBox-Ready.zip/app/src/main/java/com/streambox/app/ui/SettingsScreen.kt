package com.streambox.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val version by vm.settingsVersion.collectAsStateWithLifecycle()
    val statuses = remember(version) { vm.sourceStatuses() }
    var tmdb by remember { mutableStateOf(vm.settings.tmdbKey) }
    var omdb by remember { mutableStateOf(vm.settings.omdbKey) }
    var show by remember { mutableStateOf(false) }
    val lang = remember(version) { vm.settings.contentLang }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("الإعدادات", onBack = vm::back)

        Heading("مصادر البيانات")
        statuses.forEach { s ->
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(12.dp))
                    .background(Brand.card).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(s.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(s.description, color = Brand.muted, fontSize = 12.sp)
                    val state = when {
                        !s.enabled -> "معطّل"
                        s.requiresKey && !s.hasKey -> "يحتاج مفتاح API"
                        else -> "يعمل"
                    }
                    Text(state, color = if (state == "يعمل") Brand.accent else Color(0xFFFFB74D), fontSize = 12.sp)
                }
                Switch(
                    checked = s.enabled, onCheckedChange = { vm.setSourceEnabled(s.id, it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = Brand.accent, checkedThumbColor = Color.Black),
                )
            }
        }

        Heading("مفاتيح API (مجانية)")
        Text(
            "تُحفظ المفاتيح على هاتفك فقط ولا تُرفع إلى GitHub ولا تُضمّن في التطبيق.",
            color = Brand.muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp),
        )
        KeyField("مفتاح TMDB (v3 أو Read Access Token)", tmdb, show) { tmdb = it }
        LinkButton("احصل على مفتاح TMDB مجاناً") { open(ctx, "https://www.themoviedb.org/settings/api") }
        KeyField("مفتاح OMDb (اختياري)", omdb, show) { omdb = it }
        LinkButton("احصل على مفتاح OMDb مجاناً") { open(ctx, "https://www.omdbapi.com/apikey.aspx") }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ show = !show }) {
                Icon(if (show) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "إظهار المفاتيح", tint = Color.White)
            }
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(Brand.accent).clickable {
                    vm.saveKeys(tmdb, omdb)
                    Toast.makeText(ctx, "تم حفظ المفاتيح", Toast.LENGTH_SHORT).show()
                }.padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) { Text("حفظ المفاتيح", color = Color.Black, fontWeight = FontWeight.Bold) }
        }

        Heading("لغة المحتوى")
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("العربية", selected = lang == "ar") { vm.setLanguage("ar") }
            Pill("English", selected = lang == "en") { vm.setLanguage("en") }
        }

        Heading("البيانات")
        Box(
            Modifier.padding(horizontal = 16.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.12f))
                .clickable {
                    vm.clearCache()
                    Toast.makeText(ctx, "تم مسح الذاكرة المؤقتة", Toast.LENGTH_SHORT).show()
                }.padding(horizontal = 16.dp, vertical = 12.dp),
        ) { Text("مسح الذاكرة المؤقتة وإعادة التحميل", color = Color.White) }

        Heading("حول التطبيق")
        Text(
            "StreamBox 1.0 — تطبيق معلومات للأفلام والمسلسلات والأنمي. لا يحتوي على أي روابط بث.\n\n" +
                "This product uses the TMDB API but is not endorsed or certified by TMDB.\n" +
                "Series data by TVmaze.com • Anime data via Jikan (MyAnimeList) • Ratings via OMDb.",
            color = Brand.muted, fontSize = 12.sp, lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun Heading(text: String) {
    Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 8.dp))
}

@Composable
private fun KeyField(label: String, value: String, visible: Boolean, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true, label = { Text(label) },
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Brand.card, unfocusedContainerColor = Brand.card,
            focusedBorderColor = Brand.accent, unfocusedBorderColor = Color.Transparent,
            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            focusedLabelColor = Brand.accent, unfocusedLabelColor = Brand.muted, cursorColor = Brand.accent,
        ),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
    )
}

@Composable
private fun LinkButton(text: String, onClick: () -> Unit) {
    Text(
        text, color = Brand.accent, fontSize = 13.sp,
        modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 4.dp),
    )
}

private fun open(ctx: Context, url: String) {
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}
