package com.streambox.app.data

import android.content.Context

/** User settings. API keys are typed by the user and kept only in this app's private storage. */
class Settings(context: Context) {
    private val p = context.getSharedPreferences("streambox_settings", Context.MODE_PRIVATE)

    var tmdbKey: String
        get() = (p.getString("tmdb_key", "") ?: "").trim()
        set(v) { p.edit().putString("tmdb_key", v.trim()).apply() }

    var omdbKey: String
        get() = (p.getString("omdb_key", "") ?: "").trim()
        set(v) { p.edit().putString("omdb_key", v.trim()).apply() }

    /** "ar" or "en" */
    var contentLang: String
        get() = p.getString("lang", "ar") ?: "ar"
        set(v) { p.edit().putString("lang", v).apply() }

    fun tmdbLanguage(): String = if (contentLang == "ar") "ar" else "en-US"

    fun isEnabled(sourceId: String): Boolean = p.getBoolean("enabled_$sourceId", true)
    fun setEnabled(sourceId: String, value: Boolean) { p.edit().putBoolean("enabled_$sourceId", value).apply() }
}
