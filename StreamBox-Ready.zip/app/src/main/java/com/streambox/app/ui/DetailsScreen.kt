package com.streambox.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.streambox.app.data.Episode
import com.streambox.app.data.MediaItem
import com.streambox.app.data.MediaType

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DetailsScreen(vm: AppViewModel, item: MediaItem) {
    val ctx = LocalContext.current
    val st by vm.detailsState.collectAsStateWithLifecycle()
    val favKeys by vm.favKeys.collectAsStateWithLifecycle()
    val watchKeys by vm.watchKeys.collectAsStateWithLifecycle()
    LaunchedEffect(item.key) { vm.loadDetails(item) }

    val details = st.details?.takeIf { it.item.key == item.key }
    val shown = details?.item ?: item
    val loading = st.loading && st.item?.key == item.key
    val error = if (st.item?.key == item.key) st.error else null

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        // Backdrop header
        Box(Modifier.fillMaxWidth().height(300.dp)) {
            val bg = shown.backdrop ?: shown.poster
            if (bg != null) {
                AsyncImage(model = bg, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.4f), Color.Transparent, Brand.bgTop))
                )
            )
            IconButton(onClick = vm::back, modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "رجوع", tint = Color.White)
            }
            Row(Modifier.align(Alignment.BottomStart).padding(16.dp), verticalAlignment = Alignment.Bottom) {
                PosterImage(shown.poster, Modifier.width(100.dp).aspectRatio(2f / 3f))
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(shown.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        listOfNotNull(shown.year, details?.runtime, shown.type.singularAr).joinToString(" • "),
                        color = Brand.muted, fontSize = 13.sp,
                    )
                    shown.rating?.let {
                        Spacer(Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Star, null, tint = Color(0xFFFFC83D), modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(fmtRating(it), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        // Actions
        FlowRow(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val isFav = shown.key in favKeys
            val inWatch = shown.key in watchKeys
            ActionButton(
                if (isFav) "في المفضلة" else "أضف للمفضلة",
                if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, isFav,
            ) { vm.toggleFavorite(shown) }
            ActionButton(
                if (inWatch) "في القائمة" else "قائمة المشاهدة",
                if (inWatch) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder, inWatch,
            ) { vm.toggleWatchlist(shown) }
            details?.trailerUrl?.let { url ->
                ActionButton("الإعلان", Icons.Rounded.PlayArrow) { openUrl(ctx, url) }
            }
            if (shown.type != MediaType.MOVIE) {
                ActionButton("المواسم والحلقات", Icons.Rounded.VideoLibrary) { vm.navigate(Screen.Seasons(shown)) }
            }
        }

        if (loading) {
            Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Brand.accent, modifier = Modifier.size(28.dp))
            }
        }
        if (error != null) ErrorBox(error, onRetry = { vm.loadDetails(item, force = true) })

        details?.tagline?.let {
            Text(it, color = Brand.accent, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        if (shown.genres.isNotEmpty()) {
            FlowRow(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) { shown.genres.forEach { Pill(it) } }
        }

        val ratings = buildList {
            shown.rating?.let { add((if (shown.source == "jikan") "MyAnimeList" else "التقييم") to fmtRating(it)) }
            details?.extraRatings?.let { addAll(it) }
        }
        if (ratings.isNotEmpty()) {
            Section("التقييمات") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ratings.forEach { (label, value) -> Pill("$label: $value") }
                }
            }
        }
        shown.overview?.let { Section("القصة") { Text(it, color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp, lineHeight = 22.sp) } }

        details?.providers?.takeIf { it.isNotEmpty() }?.let { p ->
            Section("أين تشاهد (قانونياً)") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    p.forEach { Pill(it) }
                }
            }
        }
        details?.cast?.takeIf { it.isNotEmpty() }?.let { c ->
            Section("طاقم التمثيل") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    c.forEach { Pill(it) }
                }
            }
        }
        details?.facts?.takeIf { it.isNotEmpty() }?.let { f ->
            Section("معلومات") {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    f.forEach { (k, v) ->
                        Row {
                            Text("$k: ", color = Brand.muted, fontSize = 13.sp)
                            Text(v, color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
        Text(
            "المصدر: " + shown.source.uppercase() + " — العرض هنا للمعلومات فقط، لا يوجد بث داخل التطبيق.",
            color = Brand.muted, fontSize = 11.sp, modifier = Modifier.padding(16.dp),
        )
    }
}

private fun openUrl(ctx: android.content.Context, url: String) {
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

@Composable
fun SeasonsScreen(vm: AppViewModel, item: MediaItem) {
    val st by vm.detailsState.collectAsStateWithLifecycle()
    val epMap by vm.episodes.collectAsStateWithLifecycle()
    LaunchedEffect(item.key) { vm.loadDetails(item) }

    val details = st.details?.takeIf { it.item.key == item.key }
    val seasons = details?.seasons ?: emptyList()
    var selected by remember(item.key) { mutableStateOf<Int?>(null) }
    val current = selected ?: seasons.firstOrNull()?.number
    LaunchedEffect(item.key, current, details?.sourceId) {
        if (current != null) vm.loadEpisodes(item, current)
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(item.title, onBack = vm::back)
        when {
            seasons.isEmpty() && (st.loading || details == null && st.error == null) -> CenterLoading()
            seasons.isEmpty() -> ErrorBox(st.error ?: "لا توجد مواسم متاحة لهذا العنوان", onRetry = { vm.loadDetails(item, force = true) })
            else -> {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(seasons, key = { it.number }) { s ->
                        val label = if (s.episodeCount > 0 && item.type == MediaType.TV) "${s.name} (${s.episodeCount})" else s.name
                        Pill(label, selected = s.number == current) { selected = s.number }
                    }
                }
                val es = epMap["${item.key}#$current"]
                when {
                    es == null || es.loading -> CenterLoading()
                    es.error != null -> ErrorBox(es.error, onRetry = { current?.let { vm.loadEpisodes(item, it, force = true) } })
                    es.episodes.isEmpty() -> ErrorBox("لا توجد حلقات متاحة", null)
                    else -> LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(es.episodes, key = { it.number }) { ep -> EpisodeRow(ep) }
                    }
                }
            }
        }
    }
}

@Composable
private fun EpisodeRow(ep: Episode) {
    var expanded by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Brand.card)
            .clickableIf(ep.overview != null) { expanded = !expanded }.padding(10.dp),
    ) {
        if (ep.image != null) {
            AsyncImage(
                model = ep.image, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.width(120.dp).height(68.dp).clip(RoundedCornerShape(8.dp)),
            )
            Spacer(Modifier.width(10.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                "الحلقة ${ep.number}" + if (ep.name.isNotBlank()) " • ${ep.name}" else "",
                color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = if (expanded) 4 else 2, overflow = TextOverflow.Ellipsis,
            )
            val meta = listOfNotNull(
                ep.airDate, ep.runtime?.let { "$it دقيقة" }, ep.rating?.let { "★ ${fmtRating(it)}" },
            ).joinToString(" • ")
            if (meta.isNotEmpty()) Text(meta, color = Brand.muted, fontSize = 12.sp)
            ep.overview?.let {
                Spacer(Modifier.height(4.dp))
                Text(
                    it, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp,
                    maxLines = if (expanded) 20 else 2, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

private fun Modifier.clickableIf(enabled: Boolean, onClick: () -> Unit): Modifier =
    if (enabled) this.then(Modifier.clickable(onClick = onClick)) else this
