package com.streambox.app.data

import org.json.JSONArray
import org.json.JSONObject

enum class MediaType(val labelAr: String, val singularAr: String) {
    MOVIE("أفلام", "فيلم"),
    TV("مسلسلات", "مسلسل"),
    ANIME("أنمي", "أنمي"),
}

enum class Feed(val labelAr: String) {
    TRENDING("الرائج"),
    POPULAR("الأشهر"),
    LATEST("الأحدث"),
}

/** [source] is the id of the source that produced the item: tmdb, tvmaze, jikan or omdb. */
data class MediaItem(
    val key: String,
    val type: MediaType,
    val title: String,
    val originalTitle: String? = null,
    val year: String? = null,
    val poster: String? = null,
    val backdrop: String? = null,
    val rating: Double? = null,
    val overview: String? = null,
    val genres: List<String> = emptyList(),
    val source: String,
    val ids: Map<String, String> = emptyMap(),
)

data class SeasonInfo(val number: Int, val name: String, val episodeCount: Int, val year: String?, val poster: String?)

data class Episode(
    val number: Int,
    val name: String,
    val overview: String?,
    val airDate: String?,
    val runtime: Int?,
    val image: String?,
    val rating: Double?,
)

data class Details(
    val item: MediaItem,
    val sourceId: String,
    val tagline: String? = null,
    val runtime: String? = null,
    val cast: List<String> = emptyList(),
    val trailerUrl: String? = null,
    val providers: List<String> = emptyList(),
    val seasons: List<SeasonInfo> = emptyList(),
    val extraRatings: List<Pair<String, String>> = emptyList(),
    val facts: List<Pair<String, String>> = emptyList(),
)

data class Genre(
    val id: String,
    val nameAr: String,
    val tmdbMovie: Int? = null,
    val tmdbTv: Int? = null,
    val jikan: Int? = null,
    val tvmaze: String? = null,
) {
    fun supports(type: MediaType) = when (type) {
        MediaType.MOVIE -> tmdbMovie != null
        MediaType.TV -> tmdbTv != null || tvmaze != null
        MediaType.ANIME -> jikan != null
    }
}

object GenreList {
    val all = listOf(
        Genre("action", "أكشن", 28, 10759, 1, "Action"),
        Genre("adventure", "مغامرة", 12, 10759, 2, "Adventure"),
        Genre("comedy", "كوميديا", 35, 35, 4, "Comedy"),
        Genre("drama", "دراما", 18, 18, 8, "Drama"),
        Genre("horror", "رعب", 27, null, 14, "Horror"),
        Genre("scifi", "خيال علمي", 878, 10765, 24, "Science-Fiction"),
        Genre("romance", "رومانسي", 10749, null, 22, "Romance"),
        Genre("fantasy", "فانتازيا", 14, 10765, 10, "Fantasy"),
        Genre("mystery", "غموض", 9648, 9648, 7, "Mystery"),
        Genre("crime", "جريمة", 80, 80, null, "Crime"),
        Genre("thriller", "إثارة", 53, null, null, "Thriller"),
        Genre("family", "عائلي", 10751, 10751, null, "Family"),
        Genre("doc", "وثائقي", 99, 99, null, null),
        Genre("animation", "رسوم متحركة", 16, 16, null, null),
    )
}

val tmdbGenreNames: Map<Int, String> = mapOf(
    28 to "أكشن", 12 to "مغامرة", 16 to "رسوم متحركة", 35 to "كوميديا", 80 to "جريمة",
    99 to "وثائقي", 18 to "دراما", 10751 to "عائلي", 14 to "فانتازيا", 36 to "تاريخي",
    27 to "رعب", 10402 to "موسيقى", 9648 to "غموض", 10749 to "رومانسي", 878 to "خيال علمي",
    10770 to "فيلم تلفزيوني", 53 to "إثارة", 10752 to "حرب", 37 to "غربي",
    10759 to "أكشن ومغامرة", 10762 to "أطفال", 10763 to "أخبار", 10764 to "واقعي",
    10765 to "خيال علمي وفانتازيا", 10766 to "مسلسل درامي", 10767 to "حواري", 10768 to "حرب وسياسة",
)

private val genreAr = mapOf(
    "Action" to "أكشن", "Adventure" to "مغامرة", "Animation" to "رسوم متحركة", "Comedy" to "كوميديا",
    "Crime" to "جريمة", "Documentary" to "وثائقي", "Drama" to "دراما", "Family" to "عائلي",
    "Fantasy" to "فانتازيا", "History" to "تاريخي", "Horror" to "رعب", "Music" to "موسيقى",
    "Mystery" to "غموض", "Romance" to "رومانسي", "Science-Fiction" to "خيال علمي",
    "Sci-Fi" to "خيال علمي", "Thriller" to "إثارة", "War" to "حرب", "Western" to "غربي",
    "Sports" to "رياضة", "Sport" to "رياضة", "Supernatural" to "خارق للطبيعة", "Suspense" to "تشويق",
    "Slice of Life" to "شريحة من الحياة", "Award Winning" to "حائز على جوائز", "Biography" to "سيرة ذاتية",
    "Medical" to "طبي", "Legal" to "قانوني", "Food" to "طعام", "Travel" to "سفر", "Anime" to "أنمي",
)

fun genreArabic(en: String): String = genreAr[en] ?: en

private val htmlTag = Regex("<[^>]*>")
fun stripHtml(s: String?): String? =
    s?.replace(htmlTag, "")?.replace("&amp;", "&")?.replace("&quot;", "\"")?.replace("&#39;", "'")?.trim()?.ifEmpty { null }

fun MediaItem.toJson(): JSONObject = JSONObject().apply {
    put("key", key)
    put("type", type.name)
    put("title", title)
    putOpt("originalTitle", originalTitle)
    putOpt("year", year)
    putOpt("poster", poster)
    putOpt("backdrop", backdrop)
    putOpt("rating", rating)
    putOpt("overview", overview)
    put("genres", JSONArray(genres))
    put("source", source)
    put("ids", JSONObject(ids))
}

fun mediaItemFromJson(o: JSONObject): MediaItem = MediaItem(
    key = o.getString("key"),
    type = MediaType.valueOf(o.getString("type")),
    title = o.getString("title"),
    originalTitle = o.str("originalTitle"),
    year = o.str("year"),
    poster = o.str("poster"),
    backdrop = o.str("backdrop"),
    rating = o.dbl("rating"),
    overview = o.str("overview"),
    genres = o.optJSONArray("genres")?.strings() ?: emptyList(),
    source = o.getString("source"),
    ids = o.optJSONObject("ids")?.let { j -> j.keys().asSequence().associateWith { k -> j.optString(k) } }
        ?: emptyMap(),
)

fun itemsToJson(items: List<MediaItem>): String =
    JSONArray().also { arr -> items.forEach { arr.put(it.toJson()) } }.toString()

fun itemsFromJson(text: String): List<MediaItem>? = try {
    JSONArray(text).objects().map { mediaItemFromJson(it) }
} catch (e: Exception) {
    null
}
