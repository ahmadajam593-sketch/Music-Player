package com.streambox.app.data

import org.json.JSONObject
import java.net.URLEncoder

/** OMDb: search fallback + IMDb / Rotten Tomatoes / Metacritic ratings. Needs a free API key. */
class OmdbSource(settings: Settings) : MediaSource(settings) {
    override val id = "omdb"
    override val displayName = "OMDb"
    override val idKey = "imdb"
    override val requiresKey = true
    override val providesFeeds = false
    override fun hasCredentials() = settings.omdbKey.isNotBlank()
    override fun supports(type: MediaType) = type != MediaType.ANIME

    private suspend fun call(vararg params: Pair<String, String>): JSONObject {
        val q = params.joinToString("&") { (k, v) -> "$k=${URLEncoder.encode(v, "UTF-8")}" }
        return JSONObject(Http.get("https://www.omdbapi.com/?apikey=${URLEncoder.encode(settings.omdbKey, "UTF-8")}&$q"))
    }

    override suspend fun search(query: String, type: MediaType?): List<MediaItem> {
        if (type == MediaType.ANIME) return emptyList()
        val params = mutableListOf("s" to query)
        if (type == MediaType.MOVIE) params += "type" to "movie"
        if (type == MediaType.TV) params += "type" to "series"
        val o = call(*params.toTypedArray())
        if (o.str("Response") == "False") return emptyList()
        return o.optJSONArray("Search")?.objects()?.mapNotNull { s ->
            val t = when (s.str("Type")) {
                "movie" -> MediaType.MOVIE
                "series" -> MediaType.TV
                else -> return@mapNotNull null
            }
            val imdb = s.str("imdbID") ?: return@mapNotNull null
            val title = s.str("Title") ?: return@mapNotNull null
            MediaItem(
                key = "omdb:${t.name}:$imdb", type = t, title = title, originalTitle = title,
                year = s.str("Year")?.take(4), poster = s.str("Poster"), source = id,
                ids = mapOf("imdb" to imdb),
            )
        } ?: emptyList()
    }

    override suspend fun details(item: MediaItem): Details? {
        val imdb = item.ids["imdb"] ?: return null
        val o = call("i" to imdb, "plot" to "full")
        if (o.str("Response") == "False") return null
        val facts = buildList {
            o.str("Director")?.let { add("المخرج" to it) }
            o.str("Awards")?.let { add("الجوائز" to it) }
            o.str("Country")?.let { add("البلد" to it) }
        }
        return Details(
            item = item.copy(
                overview = o.str("Plot") ?: item.overview,
                poster = o.str("Poster") ?: item.poster,
                genres = o.str("Genre")?.split(",")?.map { genreArabic(it.trim()) } ?: item.genres,
                rating = o.str("imdbRating")?.toDoubleOrNull() ?: item.rating,
            ),
            sourceId = id,
            runtime = o.str("Runtime"),
            cast = o.str("Actors")?.split(",")?.map { it.trim() } ?: emptyList(),
            facts = facts,
        )
    }

    suspend fun ratings(imdbId: String): List<Pair<String, String>> {
        val o = call("i" to imdbId)
        if (o.str("Response") == "False") return emptyList()
        val out = mutableListOf<Pair<String, String>>()
        o.str("imdbRating")?.let { out += "IMDb" to "$it/10" }
        o.optJSONArray("Ratings")?.objects()?.forEach { r ->
            val v = r.str("Value") ?: return@forEach
            when (r.str("Source")) {
                "Rotten Tomatoes" -> out += "Rotten Tomatoes" to v
                "Metacritic" -> out += "Metacritic" to v
            }
        }
        return out
    }
}
