package com.streambox.app.data

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.LocalDate

/** TVmaze: TV shows, schedules, seasons and episodes. Free, no API key. */
class TvMazeSource(settings: Settings) : MediaSource(settings) {
    override val id = "tvmaze"
    override val displayName = "TVmaze"
    override val idKey = "tvmaze"
    override fun supports(type: MediaType) = type == MediaType.TV

    private val base = "https://api.tvmaze.com"

    private fun rawGenres(o: JSONObject): List<String> = o.optJSONArray("genres")?.strings() ?: emptyList()

    private fun parseShow(o: JSONObject): MediaItem? {
        val sid = o.optLong("id", -1)
        if (sid < 0) return null
        val name = o.str("name") ?: return null
        val imdb = o.optJSONObject("externals")?.str("imdb")
        val ids = buildMap {
            put("tvmaze", sid.toString())
            if (imdb != null) put("imdb", imdb)
        }
        val image = o.optJSONObject("image")
        return MediaItem(
            key = "tvmaze:TV:$sid",
            type = MediaType.TV,
            title = name,
            originalTitle = name,
            year = o.str("premiered")?.take(4),
            poster = image?.str("medium") ?: image?.str("original"),
            backdrop = image?.str("original"),
            rating = o.optJSONObject("rating")?.dbl("average")?.takeIf { it > 0 },
            overview = stripHtml(o.str("summary")),
            genres = rawGenres(o).map { genreArabic(it) },
            source = id,
            ids = ids,
        )
    }

    private suspend fun scheduleShows(dayOffset: Long): List<JSONObject> {
        val date = LocalDate.now().plusDays(dayOffset)
        val arr = JSONArray(Http.get("$base/schedule?country=US&date=$date"))
        return arr.objects().mapNotNull { it.optJSONObject("show") }
    }

    override suspend fun feed(type: MediaType, feed: Feed, page: Int, genre: Genre?): List<MediaItem> {
        if (page > 1) return emptyList()
        val offsets = if (feed == Feed.POPULAR) listOf(-1L, 0L, 1L, 2L) else listOf(0L)
        val shows = coroutineScope {
            offsets.map { off -> async { runCatching { scheduleShows(off) }.getOrDefault(emptyList()) } }.awaitAll()
        }.flatten()
        val wanted = genre?.tvmaze
        val filtered = shows
            .filter { wanted == null || rawGenres(it).contains(wanted) }
            .mapNotNull { parseShow(it) }
            .filter { it.poster != null }
            .distinctBy { it.key }
        if (genre != null && wanted == null) return emptyList()
        return if (feed == Feed.LATEST) filtered else filtered.sortedByDescending { it.rating ?: 0.0 }
    }

    override suspend fun search(query: String, type: MediaType?): List<MediaItem> {
        if (type != null && type != MediaType.TV) return emptyList()
        val arr = JSONArray(Http.get("$base/search/shows?q=${URLEncoder.encode(query, "UTF-8")}"))
        return arr.objects().mapNotNull { it.optJSONObject("show") }.mapNotNull { parseShow(it) }
    }

    override suspend fun details(item: MediaItem): Details? {
        val sid = item.ids["tvmaze"] ?: return null
        val o = JSONObject(Http.get("$base/shows/$sid?embed=cast"))
        val parsed = parseShow(o) ?: return null
        val cast = o.optJSONObject("_embedded")?.optJSONArray("cast")?.objects()
            ?.take(12)?.mapNotNull { it.optJSONObject("person")?.str("name") } ?: emptyList()
        val seasons = runCatching {
            JSONArray(Http.get("$base/shows/$sid/seasons")).objects().map { s ->
                val n = s.intOrNull("number") ?: 0
                SeasonInfo(
                    number = n,
                    name = "الموسم $n",
                    episodeCount = s.intOrNull("episodeOrder") ?: 0,
                    year = s.str("premiereDate")?.take(4),
                    poster = s.optJSONObject("image")?.str("medium"),
                )
            }.filter { it.number > 0 }
        }.getOrDefault(emptyList())
        val runtime = (o.intOrNull("runtime") ?: o.intOrNull("averageRuntime"))?.let { "$it دقيقة" }
        val facts = buildList {
            o.str("status")?.let { add("الحالة" to it) }
            o.str("language")?.let { add("اللغة" to it) }
            (o.optJSONObject("network")?.str("name") ?: o.optJSONObject("webChannel")?.str("name"))
                ?.let { add("القناة / المنصة" to it) }
        }
        return Details(
            item = item.copy(
                overview = parsed.overview ?: item.overview,
                genres = parsed.genres.ifEmpty { item.genres },
                backdrop = parsed.backdrop ?: item.backdrop,
                rating = parsed.rating ?: item.rating,
            ),
            sourceId = id, runtime = runtime, cast = cast, seasons = seasons, facts = facts,
        )
    }

    override suspend fun episodes(item: MediaItem, season: Int): List<Episode> {
        val sid = item.ids["tvmaze"] ?: return emptyList()
        return JSONArray(Http.get("$base/shows/$sid/episodes")).objects()
            .filter { it.intOrNull("season") == season }
            .map { e ->
                Episode(
                    number = e.intOrNull("number") ?: 0,
                    name = e.str("name") ?: "",
                    overview = stripHtml(e.str("summary")),
                    airDate = e.str("airdate"),
                    runtime = e.intOrNull("runtime"),
                    image = e.optJSONObject("image")?.str("medium"),
                    rating = e.optJSONObject("rating")?.dbl("average")?.takeIf { it > 0 },
                )
            }
    }
}
