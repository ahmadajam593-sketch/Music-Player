package com.streambox.app.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.io.IOException
import java.util.Collections

class NoSourceException(val type: MediaType) : Exception(
    when (type) {
        MediaType.MOVIE -> "لعرض الأفلام أضف مفتاح TMDB المجاني من الإعدادات"
        MediaType.TV -> "لا يوجد مصدر مفعّل للمسلسلات. فعّل أحد المصادر من الإعدادات"
        MediaType.ANIME -> "لا يوجد مصدر مفعّل للأنمي. فعّل Jikan من الإعدادات"
    }
)

data class FeedResult(val items: List<MediaItem>, val updatedAt: Long, val warnings: List<String>)
data class SearchResult(val items: List<MediaItem>, val warnings: List<String>)
data class SourceStatus(
    val id: String, val name: String, val requiresKey: Boolean,
    val enabled: Boolean, val hasKey: Boolean, val description: String,
)

/** Merges lists from several sources, removing duplicates (same type + title + compatible year). */
object Dedup {
    private fun norm(s: String?): String =
        s?.lowercase()?.replace(Regex("[^\\p{L}\\p{N}]+"), "") ?: ""

    private fun names(i: MediaItem) =
        listOf(norm(i.title), norm(i.originalTitle)).filter { it.isNotEmpty() }.distinct()

    private fun yearOk(a: String?, b: String?): Boolean {
        val x = a?.toIntOrNull() ?: return true
        val y = b?.toIntOrNull() ?: return true
        return kotlin.math.abs(x - y) <= 1
    }

    private fun combine(a: MediaItem, b: MediaItem) = a.copy(
        originalTitle = a.originalTitle ?: b.originalTitle,
        year = a.year ?: b.year,
        poster = a.poster ?: b.poster,
        backdrop = a.backdrop ?: b.backdrop,
        rating = a.rating ?: b.rating,
        overview = a.overview ?: b.overview,
        genres = a.genres.ifEmpty { b.genres },
        ids = b.ids + a.ids,
    )

    /** Round-robin through the lists so different sources are mixed fairly. */
    fun merge(lists: List<List<MediaItem>>): List<MediaItem> {
        val out = ArrayList<MediaItem>()
        val index = HashMap<String, Int>()
        val maxLen = lists.maxOfOrNull { it.size } ?: 0
        for (i in 0 until maxLen) {
            for (list in lists) {
                val item = list.getOrNull(i) ?: continue
                val ns = names(item)
                var hit = -1
                for (n in ns) {
                    val pos = index["${item.type}|$n"]
                    if (pos != null && yearOk(out[pos].year, item.year)) { hit = pos; break }
                }
                if (hit < 0) {
                    out.add(item)
                    ns.forEach { index.putIfAbsent("${item.type}|$it", out.size - 1) }
                } else {
                    out[hit] = combine(out[hit], item)
                    ns.forEach { index.putIfAbsent("${item.type}|$it", hit) }
                }
            }
        }
        return out
    }
}

class Repository(private val settings: Settings, private val cache: DiskCache) {
    val sources: List<MediaSource> = listOf(
        TmdbSource(settings), TvMazeSource(settings), JikanSource(settings), OmdbSource(settings),
    )
    private val omdb = sources.filterIsInstance<OmdbSource>().first()
    private val ttlMs = 6L * 60 * 60 * 1000

    fun isAvailable(type: MediaType) =
        sources.any { it.supports(type) && it.providesFeeds && it.isConfigured() }

    fun activeNames(): List<String> = sources.filter { it.isConfigured() }.map { it.displayName }

    fun statuses(): List<SourceStatus> = sources.map {
        SourceStatus(
            id = it.id, name = it.displayName, requiresKey = it.requiresKey,
            enabled = settings.isEnabled(it.id), hasKey = it.hasCredentials(),
            description = when (it.id) {
                "tmdb" -> "أفلام ومسلسلات، صور عالية الجودة، تقييمات، أين تشاهد"
                "tvmaze" -> "مسلسلات وجدول العرض والحلقات (بدون مفتاح)"
                "jikan" -> "أنمي من MyAnimeList (بدون مفتاح)"
                else -> "بحث احتياطي وتقييمات IMDb وRotten Tomatoes"
            },
        )
    }

    suspend fun feed(type: MediaType, feed: Feed, page: Int, genre: Genre?, force: Boolean): FeedResult {
        val active = sources.filter { it.supports(type) && it.providesFeeds && it.isConfigured() }
        if (active.isEmpty()) throw NoSourceException(type)

        val cacheKey = "feed|$type|$feed|$page|${genre?.id}|${settings.contentLang}|${active.joinToString(",") { it.id }}"
        val cached = cache.get(cacheKey)
        val now = System.currentTimeMillis()
        if (!force && cached != null && now - cached.first < ttlMs) {
            itemsFromJson(cached.second)?.let { return FeedResult(it, cached.first, emptyList()) }
        }

        val warnings = Collections.synchronizedList(mutableListOf<String>())
        var firstError: Throwable? = null
        val lists = coroutineScope {
            active.map { s ->
                async {
                    try {
                        s.feed(type, feed, page, genre)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        warnings.add(s.displayName)
                        if (firstError == null) firstError = e
                        null
                    }
                }
            }.awaitAll()
        }.filterNotNull()

        if (lists.isEmpty()) {
            // Every source failed: fall back to stale cache if we have one.
            if (cached != null) {
                itemsFromJson(cached.second)?.let { return FeedResult(it, cached.first, warnings.toList()) }
            }
            throw firstError ?: IOException("تعذّر تحميل البيانات")
        }
        val merged = Dedup.merge(lists)
        if (merged.isNotEmpty()) cache.put(cacheKey, itemsToJson(merged))
        return FeedResult(merged, now, warnings.toList())
    }

    suspend fun search(query: String, type: MediaType?): SearchResult {
        val active = sources.filter { it.isConfigured() && (type == null || it.supports(type)) }
        if (active.isEmpty()) throw NoSourceException(type ?: MediaType.MOVIE)
        val warnings = Collections.synchronizedList(mutableListOf<String>())
        var firstError: Throwable? = null
        val lists = coroutineScope {
            active.map { s ->
                async {
                    try {
                        s.search(query, type)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        warnings.add(s.displayName)
                        if (firstError == null) firstError = e
                        null
                    }
                }
            }.awaitAll()
        }.filterNotNull()
        if (lists.isEmpty()) throw firstError ?: IOException("تعذّر البحث")
        val items = Dedup.merge(lists.map { l -> l.filter { type == null || it.type == type } })
        return SearchResult(items, warnings.toList())
    }

    /** Tries the item's own source first, then any other source that knows the item. */
    suspend fun details(item: MediaItem): Details {
        val ordered = (sources.filter { it.id == item.source } + sources.filter { it.id != item.source })
            .filter { it.supports(item.type) && it.isConfigured() && item.ids.containsKey(it.idKey) }
        var lastError: Throwable? = null
        var found: Details? = null
        for (s in ordered) {
            try {
                found = s.details(item)
                if (found != null) break
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = e
            }
        }
        var result = found ?: throw lastError ?: IOException("لا توجد تفاصيل متاحة")
        val imdb = result.item.ids["imdb"]
        if (imdb != null && omdb.isConfigured() && result.item.type != MediaType.ANIME) {
            val ratings = runCatching { omdb.ratings(imdb) }.getOrDefault(emptyList())
            if (ratings.isNotEmpty()) result = result.copy(extraRatings = ratings)
        }
        return result
    }

    suspend fun episodes(item: MediaItem, season: Int, sourceId: String): List<Episode> {
        val s = sources.firstOrNull { it.id == sourceId } ?: throw IOException("المصدر غير متاح")
        return s.episodes(item, season)
    }
}
