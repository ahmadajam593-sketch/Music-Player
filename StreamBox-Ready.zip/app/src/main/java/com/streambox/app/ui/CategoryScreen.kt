package com.streambox.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.streambox.app.data.Feed
import com.streambox.app.data.Genre
import com.streambox.app.data.GenreList
import com.streambox.app.data.MediaType

/** Browse one type (movies / series / anime) with feed tabs, genre filter and infinite scroll. */
@Composable
fun CategoryScreen(vm: AppViewModel, start: Screen.Category) {
    var type by remember { mutableStateOf(start.type) }
    var feed by remember { mutableStateOf(start.feed) }
    var genre by remember { mutableStateOf(start.genre) }
    val version by vm.settingsVersion.collectAsStateWithLifecycle()

    val unsupportedGenre = genre?.let { !it.supports(type) } ?: false
    val key = FeedKey(type, feed, genre)
    LaunchedEffect(key, version, unsupportedGenre) { if (!unsupportedGenre) vm.load(key) }
    val st = feedStateOf(vm, key)
    val gridState = rememberLazyGridState()

    LaunchedEffect(key, st?.items?.size) {
        snapshotFlow { gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index }.collect { last ->
            val total = st?.items?.size ?: 0
            if (last != null && total > 0 && last >= total - 6) vm.loadMore(key)
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(
            title = (genre?.let { "${it.nameAr} • " } ?: "") + type.labelAr,
            onBack = vm::back,
            actions = {
                IconButton(onClick = { vm.navigate(Screen.Search) }) {
                    Icon(Icons.Rounded.Search, "بحث", tint = Color.White)
                }
            },
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(MediaType.values().toList()) { t ->
                Pill(t.labelAr, selected = t == type) { type = t }
            }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(Feed.values().toList()) { f ->
                Pill(f.labelAr, selected = f == feed) { feed = f }
            }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item { Pill("كل التصنيفات", selected = genre == null) { genre = null } }
            items(GenreList.all, key = { it.id }) { g ->
                Pill(g.nameAr, selected = g == genre) { genre = g }
            }
        }
        Box(Modifier.fillMaxSize().padding(top = 8.dp)) {
            when {
                unsupportedGenre -> ErrorBox("هذا التصنيف غير متاح لقسم ${type.labelAr}. جرّب قسماً آخر أو تصنيفاً آخر.", null)
                st == null || (st.loading && st.items.isEmpty()) -> CenterLoading()
                st.items.isEmpty() && st.needsKey ->
                    NeedKeyBox(st.error ?: "أضف مفتاح API من الإعدادات", onSettings = { vm.navigate(Screen.Settings) })
                st.items.isEmpty() && st.error != null -> ErrorBox(st.error, onRetry = { vm.load(key, force = true) })
                st.items.isEmpty() -> ErrorBox("لا توجد نتائج", null)
                else -> LazyVerticalGrid(
                    state = gridState,
                    columns = GridCells.Adaptive(116.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(st.items, key = { it.key }) { item ->
                        PosterCard(item, onClick = { vm.navigate(Screen.Details(item)) })
                    }
                    if (st.loading) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Box(Modifier.fillMaxWidth().height(60.dp), contentAlignment = Alignment.Center) {
                                androidx.compose.material3.CircularProgressIndicator(color = Brand.accent)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GenresScreen(vm: AppViewModel) {
    Column(Modifier.fillMaxSize()) {
        TopBar("التصنيفات", onBack = vm::back)
        LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(GenreList.all, key = { it.id }) { g -> GenreTile(g, GenreList.all.indexOf(g)) {
                val t = vm.defaultTypeFor(g)
                vm.navigate(Screen.Category(t, Feed.TRENDING, g))
            } }
        }
    }
}

@Composable
private fun GenreTile(g: Genre, index: Int, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(86.dp).clip(RoundedCornerShape(14.dp))
            .background(Brand.genreBrushes[index % Brand.genreBrushes.size])
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(g.nameAr, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}
