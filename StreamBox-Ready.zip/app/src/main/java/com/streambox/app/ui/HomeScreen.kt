package com.streambox.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.LiveTv
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.PlayCircleOutline
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.streambox.app.data.Feed
import com.streambox.app.data.MediaType
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

private data class RailSpec(val title: String, val key: FeedKey)

@Composable
fun feedStateOf(vm: AppViewModel, key: FeedKey): FeedState? {
    val flow = remember(key) { vm.feeds.map { it[key] }.distinctUntilChanged() }
    val state by flow.collectAsStateWithLifecycle(initialValue = null)
    return state
}

@Composable
fun HomeScreen(vm: AppViewModel, listState: LazyListState) {
    val version by vm.settingsVersion.collectAsStateWithLifecycle()
    val moviesOn = remember(version) { vm.moviesAvailable() }
    val sourcesLine = remember(version) { vm.activeSourcesLine() }

    val rails = remember(moviesOn) {
        buildList {
            if (moviesOn) {
                add(RailSpec("أفلام رائجة", FeedKey(MediaType.MOVIE, Feed.TRENDING)))
                add(RailSpec("أفلام الأشهر", FeedKey(MediaType.MOVIE, Feed.POPULAR)))
                add(RailSpec("أحدث الأفلام", FeedKey(MediaType.MOVIE, Feed.LATEST)))
            }
            add(RailSpec("مسلسلات رائجة", FeedKey(MediaType.TV, Feed.TRENDING)))
            add(RailSpec("مسلسلات الأشهر", FeedKey(MediaType.TV, Feed.POPULAR)))
            add(RailSpec("أحدث المسلسلات", FeedKey(MediaType.TV, Feed.LATEST)))
            add(RailSpec("أنمي رائج الآن", FeedKey(MediaType.ANIME, Feed.TRENDING)))
            add(RailSpec("أنمي الأشهر", FeedKey(MediaType.ANIME, Feed.POPULAR)))
            add(RailSpec("أحدث الأنمي", FeedKey(MediaType.ANIME, Feed.LATEST)))
        }
    }

    LazyColumn(state = listState, contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            TopBar(
                title = "StreamBox", onBack = null,
                actions = {
                    IconButton(onClick = { vm.navigate(Screen.Search) }) {
                        Icon(Icons.Rounded.Search, "بحث", tint = Color.White)
                    }
                    IconButton(onClick = { vm.navigate(Screen.Settings) }) {
                        Icon(Icons.Rounded.Settings, "الإعدادات", tint = Color.White)
                    }
                },
            )
        }
        item { Dashboard(vm, moviesOn) }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp)) {
                Text(
                    "المصادر المفعّلة: $sourcesLine", color = Brand.muted, fontSize = 12.sp,
                    modifier = Modifier.weight(1f),
                )
                Text("التحديث التلقائي كل 6 ساعات", color = Brand.muted, fontSize = 12.sp)
            }
        }
        if (!moviesOn) {
            item {
                NeedKeyBox(
                    "لعرض الأفلام أضف مفتاح TMDB المجاني من الإعدادات. المسلسلات والأنمي تعمل بدون مفتاح.",
                    onSettings = { vm.navigate(Screen.Settings) },
                )
            }
        }
        items(rails, key = { it.title }) { spec ->
            FeedRail(vm, spec.title, spec.key)
        }
    }
}

@Composable
private fun FeedRail(vm: AppViewModel, title: String, key: FeedKey) {
    val version by vm.settingsVersion.collectAsStateWithLifecycle()
    LaunchedEffect(key, version) { vm.load(key) }
    val st = feedStateOf(vm, key)
    Column {
        SectionHeader(title, onSeeAll = { vm.navigate(Screen.Category(key.type, key.feed)) })
        when {
            st == null || (st.loading && st.items.isEmpty()) -> LoadingRail()
            st.items.isEmpty() && st.error != null ->
                ErrorBox(st.error, onRetry = { vm.load(key, force = true) })
            st.items.isEmpty() -> Text("لا توجد نتائج", color = Brand.muted, modifier = Modifier.padding(16.dp))
            else -> LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(st.items, key = { it.key }) { item ->
                    PosterCard(
                        item, Modifier.width(120.dp),
                        onClick = { vm.navigate(Screen.Details(item)) },
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Dashboard: the tile grid from the reference screenshot
// ---------------------------------------------------------------------------

@Composable
private fun Dashboard(vm: AppViewModel, moviesOn: Boolean) {
    val version by vm.settingsVersion.collectAsStateWithLifecycle()
    LaunchedEffect(version, moviesOn) {
        if (moviesOn) vm.load(FeedKey(MediaType.MOVIE, Feed.TRENDING))
        vm.load(FeedKey(MediaType.TV, Feed.TRENDING))
        vm.load(FeedKey(MediaType.ANIME, Feed.TRENDING))
    }
    val movieTs = feedStateOf(vm, FeedKey(MediaType.MOVIE, Feed.TRENDING))?.updatedAt ?: 0L
    val tvTs = feedStateOf(vm, FeedKey(MediaType.TV, Feed.TRENDING))?.updatedAt ?: 0L
    val animeTs = feedStateOf(vm, FeedKey(MediaType.ANIME, Feed.TRENDING))?.updatedAt ?: 0L

    val goMovies = { vm.navigate(Screen.Category(MediaType.MOVIE)) }
    val goTv = { vm.navigate(Screen.Category(MediaType.TV)) }
    val goAnime = { vm.navigate(Screen.Category(MediaType.ANIME)) }

    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        val wide = maxWidth >= 600.dp
        // The tile layout is fixed left-to-right to match the screenshot; the Arabic text inside still reads RTL.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            if (wide) {
                Row(Modifier.fillMaxWidth().height(380.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    BigTile(
                        "أنمي", Icons.Rounded.LiveTv, Brand.tealBlue, updatedLabel(animeTs), false,
                        Modifier.weight(0.9f).fillMaxHeight(), goAnime,
                    ) { vm.refreshType(MediaType.ANIME) }
                    Column(Modifier.weight(2.4f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(Modifier.weight(1.8f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            BigTile(
                                "أفلام", Icons.Rounded.PlayCircleOutline, Brand.pinkPeach,
                                if (moviesOn) updatedLabel(movieTs) else "يتطلب مفتاح TMDB", false,
                                Modifier.weight(1f).fillMaxHeight(), goMovies,
                            ) { vm.refreshType(MediaType.MOVIE) }
                            BigTile(
                                "مسلسلات", Icons.Rounded.Movie, Brand.purpleCyan, updatedLabel(tvTs), false,
                                Modifier.weight(1f).fillMaxHeight(), goTv,
                            ) { vm.refreshType(MediaType.TV) }
                        }
                        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            SmallTile("التصنيفات", Icons.Rounded.GridView, false, Modifier.weight(1f).fillMaxHeight()) {
                                vm.navigate(Screen.Genres)
                            }
                            SmallTile("قائمة المشاهدة", Icons.Rounded.Bookmarks, false, Modifier.weight(1f).fillMaxHeight()) {
                                vm.navigate(Screen.Watchlist)
                            }
                            SmallTile("المفضلة", Icons.Rounded.Favorite, false, Modifier.weight(1f).fillMaxHeight()) {
                                vm.navigate(Screen.Favorites)
                            }
                        }
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth().height(190.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        BigTile(
                            "أفلام", Icons.Rounded.PlayCircleOutline, Brand.pinkPeach,
                            if (moviesOn) updatedLabel(movieTs) else "يتطلب مفتاح TMDB", true,
                            Modifier.weight(1f).fillMaxHeight(), goMovies,
                        ) { vm.refreshType(MediaType.MOVIE) }
                        BigTile(
                            "مسلسلات", Icons.Rounded.Movie, Brand.purpleCyan, updatedLabel(tvTs), true,
                            Modifier.weight(1f).fillMaxHeight(), goTv,
                        ) { vm.refreshType(MediaType.TV) }
                    }
                    BigTile(
                        "أنمي", Icons.Rounded.LiveTv, Brand.tealBlue, updatedLabel(animeTs), true,
                        Modifier.fillMaxWidth().height(140.dp), goAnime,
                    ) { vm.refreshType(MediaType.ANIME) }
                    Row(Modifier.fillMaxWidth().height(88.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SmallTile("التصنيفات", Icons.Rounded.GridView, true, Modifier.weight(1f).fillMaxHeight()) {
                            vm.navigate(Screen.Genres)
                        }
                        SmallTile("قائمة المشاهدة", Icons.Rounded.Bookmarks, true, Modifier.weight(1f).fillMaxHeight()) {
                            vm.navigate(Screen.Watchlist)
                        }
                        SmallTile("المفضلة", Icons.Rounded.Favorite, true, Modifier.weight(1f).fillMaxHeight()) {
                            vm.navigate(Screen.Favorites)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BigTile(
    title: String,
    icon: ImageVector,
    brush: Brush,
    footer: String,
    compact: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
    onRefresh: () -> Unit,
) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(brush).clickable(onClick = onClick)) {
        Column(
            Modifier.weight(1f).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(icon, null, tint = Brand.iconTint, modifier = Modifier.size(if (compact) 44.dp else 72.dp))
            Spacer(Modifier.height(if (compact) 4.dp else 10.dp))
            Text(
                title, color = Brand.iconTint, fontSize = if (compact) 18.sp else 24.sp,
                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            )
        }
        Row(
            Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.22f)).padding(horizontal = 8.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box36(onRefresh)
            Spacer(Modifier.width(8.dp))
            Text(
                footer, color = Color.White, fontSize = if (compact) 11.sp else 13.sp,
                maxLines = 2, textAlign = TextAlign.Center, modifier = Modifier.weight(1f, fill = false),
            )
        }
    }
}

@Composable
private fun Box36(onClick: () -> Unit) {
    androidx.compose.foundation.layout.Box(
        Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFEAF6FF)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Rounded.Sync, "تحديث", tint = Color(0xFF1B2145), modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun SmallTile(title: String, icon: ImageVector, compact: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    if (compact) {
        Column(
            modifier.clip(shape).background(Brand.accent).clickable(onClick = onClick).padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(4.dp))
            Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2)
        }
    } else {
        Row(
            modifier.clip(shape).background(Brand.accent).clickable(onClick = onClick).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(40.dp))
            Spacer(Modifier.weight(1f))
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, maxLines = 2)
        }
    }
}
