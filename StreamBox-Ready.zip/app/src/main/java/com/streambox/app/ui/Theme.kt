package com.streambox.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Colors taken from the reference screenshot: dark navy background + vivid gradient tiles. */
object Brand {
    val bgTop = Color(0xFF0A0E26)
    val bgBottom = Color(0xFF0E1433)
    val bg = Brush.verticalGradient(listOf(bgTop, bgBottom))
    val accent = Color(0xFF1ECBB1)
    val card = Color(0xFF1B2145)
    val iconTint = Color(0xFFCFEFFF)
    val muted = Color(0xFFA9AEC9)

    val tealBlue = Brush.verticalGradient(listOf(Color(0xFF00D4B0), Color(0xFF0B73E8)))
    val pinkPeach = Brush.horizontalGradient(listOf(Color(0xFFD42A57), Color(0xFFE6BFA9)))
    val purpleCyan = Brush.horizontalGradient(listOf(Color(0xFF7B4DE0), Color(0xFF00C8FF)))

    val genreBrushes = listOf(
        Brush.linearGradient(listOf(Color(0xFFD42A57), Color(0xFFE6BFA9))),
        Brush.linearGradient(listOf(Color(0xFF7B4DE0), Color(0xFF00C8FF))),
        Brush.linearGradient(listOf(Color(0xFF00D4B0), Color(0xFF0B73E8))),
        Brush.linearGradient(listOf(Color(0xFFFF8A3D), Color(0xFFD42A57))),
    )
}

private val Scheme = darkColorScheme(
    primary = Brand.accent,
    onPrimary = Color.Black,
    background = Brand.bgTop,
    onBackground = Color.White,
    surface = Brand.card,
    onSurface = Color.White,
    surfaceVariant = Brand.card,
    onSurfaceVariant = Brand.muted,
)

@Composable
fun StreamBoxTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
