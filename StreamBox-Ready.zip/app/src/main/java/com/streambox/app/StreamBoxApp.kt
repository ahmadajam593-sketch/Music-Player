package com.streambox.app

import android.app.Application

class StreamBoxApp : Application()
